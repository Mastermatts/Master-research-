import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getUserRole, isStaffRole } from "@/lib/auth/roles";
import { ingestResource } from "@/lib/ai/ingest";

export const runtime = "nodejs";
export const maxDuration = 60;

async function requireStaff(supabase: Awaited<ReturnType<typeof createClient>>) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { user: null, allowed: false };
  const role = await getUserRole(supabase, user.id);
  return { user, allowed: isStaffRole(role) };
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { allowed } = await requireStaff(supabase);
  if (!allowed) return NextResponse.json({ error: "Staff access required" }, { status: 403 });

  const { data: resource } = await supabase.from("resources").select("file_url").eq("id", id).single();
  if (!resource) return NextResponse.json({ error: "Resource not found" }, { status: 404 });

  await supabase.storage.from("resources").remove([resource.file_url]);
  const { error } = await supabase.from("resources").delete().eq("id", id);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ deleted: true });
}

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { allowed } = await requireStaff(supabase);
  if (!allowed) return NextResponse.json({ error: "Staff access required" }, { status: 403 });

  const { data: resource } = await supabase.from("resources").select("file_url").eq("id", id).single();
  if (!resource) return NextResponse.json({ error: "Resource not found" }, { status: 404 });

  try {
    const result = await ingestResource(supabase, id, resource.file_url);
    return NextResponse.json({ reingested: true, ...result });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Ingestion failed" },
      { status: 500 }
    );
  }
}
