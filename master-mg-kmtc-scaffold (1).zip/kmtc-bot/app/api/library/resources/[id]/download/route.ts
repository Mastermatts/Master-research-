import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  // RLS on `resources` already blocks premium-only files for free-tier users.
  const { data: resource, error } = await supabase
    .from("resources")
    .select("id, file_url, title")
    .eq("id", id)
    .single();

  if (error || !resource) {
    return NextResponse.json({ error: "Resource not found" }, { status: 404 });
  }

  const { data: signed, error: signError } = await supabase.storage
    .from("resources")
    .createSignedUrl(resource.file_url, 60, { download: true });

  if (signError || !signed) {
    return NextResponse.json({ error: signError?.message || "Could not generate download link" }, { status: 500 });
  }

  await supabase.rpc("increment_resource_downloads", { resource_id: resource.id });

  return NextResponse.redirect(signed.signedUrl);
}
