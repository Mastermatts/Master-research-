import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getUserRole, isStaffRole } from "@/lib/auth/roles";
import { ingestResource } from "@/lib/ai/ingest";

export const runtime = "nodejs";
export const maxDuration = 60;

const PAGE_SIZE = 12;
const RESOURCE_TYPES = ["notes", "book", "slides", "manual", "revision", "past_paper"] as const;
const MAX_FILE_BYTES = 30 * 1024 * 1024; // 30MB

export async function GET(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const subjectId = searchParams.get("subjectId");
  const type = searchParams.get("type");
  const q = searchParams.get("q")?.trim();
  const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10));

  let query = supabase
    .from("resources")
    .select("id, title, description, type, year, file_size_kb, is_premium, downloads_count, created_at, subjects(id, name, department)", {
      count: "exact",
    })
    .order("created_at", { ascending: false });

  if (subjectId) query = query.eq("subject_id", subjectId);
  if (type && (RESOURCE_TYPES as readonly string[]).includes(type)) query = query.eq("type", type);
  if (q) query = query.or(`title.ilike.%${q}%,description.ilike.%${q}%`);

  const from = (page - 1) * PAGE_SIZE;
  const to = from + PAGE_SIZE - 1;
  query = query.range(from, to);

  const { data: resources, error, count } = await query;

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  // Mark which of these are bookmarked by the current user.
  const ids = (resources ?? []).map((r) => r.id);
  let bookmarkedIds: string[] = [];
  if (ids.length > 0) {
    const { data: bookmarks } = await supabase
      .from("bookmarks")
      .select("resource_id")
      .eq("user_id", user.id)
      .in("resource_id", ids);
    bookmarkedIds = (bookmarks ?? []).map((b) => b.resource_id);
  }

  return NextResponse.json({
    resources: (resources ?? []).map((r) => ({ ...r, isBookmarked: bookmarkedIds.includes(r.id) })),
    total: count ?? 0,
    page,
    pageSize: PAGE_SIZE,
  });
}

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const role = await getUserRole(supabase, user.id);
  if (!isStaffRole(role)) {
    return NextResponse.json({ error: "Only lecturers or admins can upload resources" }, { status: 403 });
  }

  const formData = await req.formData();
  const file = formData.get("file");
  const subjectId = formData.get("subjectId")?.toString();
  const type = formData.get("type")?.toString();
  const title = formData.get("title")?.toString()?.trim();
  const description = formData.get("description")?.toString()?.trim() || null;
  const year = formData.get("year")?.toString();
  const isPremium = formData.get("isPremium") === "true";

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "A file is required" }, { status: 400 });
  }
  if (!subjectId || !title || !type || !(RESOURCE_TYPES as readonly string[]).includes(type)) {
    return NextResponse.json({ error: "subjectId, title, and a valid type are required" }, { status: 400 });
  }
  if (file.size > MAX_FILE_BYTES) {
    return NextResponse.json({ error: "File exceeds the 30MB limit" }, { status: 400 });
  }

  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const storagePath = `${subjectId}/${crypto.randomUUID()}-${safeName}`;

  const { error: uploadError } = await supabase.storage
    .from("resources")
    .upload(storagePath, file, { contentType: file.type || "application/octet-stream" });

  if (uploadError) {
    return NextResponse.json({ error: `Upload failed: ${uploadError.message}` }, { status: 500 });
  }

  const { data: resource, error: insertError } = await supabase
    .from("resources")
    .insert({
      subject_id: subjectId,
      type,
      title,
      description,
      file_url: storagePath,
      file_size_kb: Math.round(file.size / 1024),
      year: year ? parseInt(year, 10) : null,
      uploaded_by: user.id,
      is_premium: isPremium,
    })
    .select("id")
    .single();

  if (insertError || !resource) {
    // Roll back the uploaded file if the DB insert failed.
    await supabase.storage.from("resources").remove([storagePath]);
    return NextResponse.json({ error: insertError?.message || "Could not save resource" }, { status: 500 });
  }

  // Ingest PDFs immediately so the AI Tutor can cite them right away.
  // Non-PDF uploads (slides exported as pptx, images, etc.) just skip this —
  // they're still browsable/downloadable, just not searchable by the tutor yet.
  let ingestion: { chunkCount: number } | { skipped: true } | { error: string };
  if (file.type === "application/pdf" || safeName.toLowerCase().endsWith(".pdf")) {
    try {
      ingestion = await ingestResource(supabase, resource.id, storagePath);
    } catch (err) {
      console.error("[library/upload] ingestion failed:", err);
      ingestion = { error: err instanceof Error ? err.message : "Ingestion failed" };
    }
  } else {
    ingestion = { skipped: true };
  }

  return NextResponse.json({ resourceId: resource.id, ingestion }, { status: 201 });
}
