import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getUserRole } from "@/lib/auth/roles";

async function requireAdmin(supabase: Awaited<ReturnType<typeof createClient>>) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { allowed: false as const };
  const role = await getUserRole(supabase, user.id);
  return { allowed: role === "admin" };
}

const EDITABLE_KEYS = [
  "label",
  "field_type",
  "options",
  "placeholder",
  "helper_text",
  "is_required",
  "sort_order",
  "is_active",
] as const;

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { allowed } = await requireAdmin(supabase);
  if (!allowed) return NextResponse.json({ error: "Admin access required" }, { status: 403 });

  const body = await req.json();
  const update: Record<string, unknown> = {};
  for (const key of EDITABLE_KEYS) {
    if (key in body) update[key] = body[key];
  }
  if (Object.keys(update).length === 0) {
    return NextResponse.json({ error: "No editable fields provided" }, { status: 400 });
  }

  const { data, error } = await supabase
    .from("research_profile_fields")
    .update(update)
    .eq("id", id)
    .select("*")
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ field: data });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { allowed } = await requireAdmin(supabase);
  if (!allowed) return NextResponse.json({ error: "Admin access required" }, { status: 403 });

  // Hard delete also removes any students' saved answers for this field
  // (FK cascade) — the UI warns about this before calling it. Prefer
  // deactivating (PATCH is_active=false) to keep historical answers.
  const { error } = await supabase.from("research_profile_fields").delete().eq("id", id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ deleted: true });
}
