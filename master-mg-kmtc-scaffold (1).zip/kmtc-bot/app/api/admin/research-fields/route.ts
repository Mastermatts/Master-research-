import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { getUserRole } from "@/lib/auth/roles";

const FIELD_TYPES = ["text", "textarea", "select", "date"] as const;

async function requireAdmin(supabase: Awaited<ReturnType<typeof createClient>>) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return { allowed: false as const };
  const role = await getUserRole(supabase, user.id);
  return { allowed: role === "admin" };
}

export async function GET() {
  const supabase = await createClient();
  const { allowed } = await requireAdmin(supabase);
  if (!allowed) return NextResponse.json({ error: "Admin access required" }, { status: 403 });

  const { data, error } = await supabase
    .from("research_profile_fields")
    .select("*")
    .order("sort_order", { ascending: true });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ fields: data });
}

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const { allowed } = await requireAdmin(supabase);
  if (!allowed) return NextResponse.json({ error: "Admin access required" }, { status: 403 });

  const body = await req.json();
  const key = body.key?.toString().trim().toLowerCase().replace(/\s+/g, "_");
  const label = body.label?.toString().trim();
  const fieldType = body.fieldType?.toString();
  const options = Array.isArray(body.options) ? body.options.filter(Boolean) : null;
  const placeholder = body.placeholder?.toString().trim() || null;
  const helperText = body.helperText?.toString().trim() || null;
  const isRequired = body.isRequired !== false;

  if (!key || !label) {
    return NextResponse.json({ error: "key and label are required" }, { status: 400 });
  }
  if (!(FIELD_TYPES as readonly string[]).includes(fieldType)) {
    return NextResponse.json({ error: "Invalid fieldType" }, { status: 400 });
  }
  if (fieldType === "select" && (!options || options.length < 2)) {
    return NextResponse.json({ error: "Select fields need at least 2 options" }, { status: 400 });
  }

  const { data: maxSort } = await supabase
    .from("research_profile_fields")
    .select("sort_order")
    .order("sort_order", { ascending: false })
    .limit(1)
    .maybeSingle();

  const { data, error } = await supabase
    .from("research_profile_fields")
    .insert({
      key,
      label,
      field_type: fieldType,
      options,
      placeholder,
      helper_text: helperText,
      is_required: isRequired,
      sort_order: (maxSort?.sort_order ?? 0) + 10,
    })
    .select("*")
    .single();

  if (error) {
    if (error.code === "23505") {
      return NextResponse.json({ error: `A field with key "${key}" already exists` }, { status: 409 });
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ field: data }, { status: 201 });
}
