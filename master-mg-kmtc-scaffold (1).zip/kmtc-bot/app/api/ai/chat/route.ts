import { NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { openai, CHAT_MODEL } from "@/lib/ai/openai";
import { TUTOR_SYSTEM_PROMPT, buildContextBlock } from "@/lib/ai/system-prompt";
import { retrieveLibraryContext } from "@/lib/ai/rag";

export const runtime = "nodejs";
export const maxDuration = 60;

const HISTORY_LIMIT = 16; // recent turns of context sent to the model
const MAX_MESSAGE_LENGTH = 4000;
const FREE_TIER_DAILY_LIMIT = 30;

type ChatRequestBody = {
  conversationId?: string;
  message: string;
};

function sseEvent(data: Record<string, unknown>) {
  return `data: ${JSON.stringify(data)}\n\n`;
}

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return new Response(JSON.stringify({ error: "Not authenticated" }), { status: 401 });
  }

  let body: ChatRequestBody;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400 });
  }

  const message = (body.message ?? "").trim();
  if (!message) {
    return new Response(JSON.stringify({ error: "Message is required" }), { status: 400 });
  }
  if (message.length > MAX_MESSAGE_LENGTH) {
    return new Response(
      JSON.stringify({ error: `Message too long (max ${MAX_MESSAGE_LENGTH} characters)` }),
      { status: 400 }
    );
  }

  // ---- Free-tier daily rate limit (premium spec item: "unlimited AI questions") ----
  const { data: profile } = await supabase
    .from("profiles")
    .select("subscription_tier")
    .eq("id", user.id)
    .single();

  if (profile?.subscription_tier !== "premium") {
    const since = new Date();
    since.setHours(0, 0, 0, 0);
    const { count } = await supabase
      .from("ai_messages")
      .select("id, ai_conversations!inner(user_id)", { count: "exact", head: true })
      .eq("role", "user")
      .eq("ai_conversations.user_id", user.id)
      .gte("created_at", since.toISOString());

    if ((count ?? 0) >= FREE_TIER_DAILY_LIMIT) {
      return new Response(
        JSON.stringify({
          error: `Free plan is limited to ${FREE_TIER_DAILY_LIMIT} AI questions per day. Upgrade to Premium for unlimited tutoring.`,
          code: "RATE_LIMITED",
        }),
        { status: 429 }
      );
    }
  }

  // ---- Get or create the conversation ----
  let conversationId = body.conversationId;
  if (!conversationId) {
    const { data: convo, error: convoError } = await supabase
      .from("ai_conversations")
      .insert({ user_id: user.id, title: message.slice(0, 60) })
      .select("id")
      .single();

    if (convoError || !convo) {
      return new Response(JSON.stringify({ error: "Could not start conversation" }), { status: 500 });
    }
    conversationId = convo.id;
  } else {
    // Confirm the conversation belongs to this user (RLS also enforces this).
    const { data: convo } = await supabase
      .from("ai_conversations")
      .select("id")
      .eq("id", conversationId)
      .eq("user_id", user.id)
      .single();
    if (!convo) {
      return new Response(JSON.stringify({ error: "Conversation not found" }), { status: 404 });
    }
  }

  // ---- Save the user's message ----
  await supabase.from("ai_messages").insert({
    conversation_id: conversationId,
    role: "user",
    content: message,
  });

  // ---- Pull recent history for context ----
  const { data: history } = await supabase
    .from("ai_messages")
    .select("role, content")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: false })
    .limit(HISTORY_LIMIT);

  const orderedHistory = (history ?? []).reverse();

  // ---- RAG: pull relevant library chunks, if any exist ----
  const chunks = await retrieveLibraryContext(supabase, message);
  const contextBlock = buildContextBlock(chunks);

  const systemPrompt = TUTOR_SYSTEM_PROMPT + contextBlock;

  const modelMessages = [
    { role: "system" as const, content: systemPrompt },
    ...orderedHistory.map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content as string,
    })),
  ];

  // ---- Stream the completion back to the client ----
  const encoder = new TextEncoder();
  let fullText = "";

  const stream = new ReadableStream({
    async start(controller) {
      controller.enqueue(encoder.encode(sseEvent({ type: "meta", conversationId })));

      try {
        const completion = await openai.chat.completions.create({
          model: CHAT_MODEL,
          messages: modelMessages,
          stream: true,
          temperature: 0.4,
        });

        for await (const part of completion) {
          const token = part.choices[0]?.delta?.content;
          if (token) {
            fullText += token;
            controller.enqueue(encoder.encode(sseEvent({ type: "token", text: token })));
          }
        }

        // Persist the assistant's full reply once streaming is done.
        if (fullText.trim()) {
          await supabase.from("ai_messages").insert({
            conversation_id: conversationId,
            role: "assistant",
            content: fullText,
          });
        }

        controller.enqueue(encoder.encode(sseEvent({ type: "done" })));
      } catch (err) {
        console.error("[ai/chat] streaming error:", err);
        controller.enqueue(
          encoder.encode(
            sseEvent({
              type: "error",
              message: "The AI Tutor hit a snag generating a response. Please try again.",
            })
          )
        );
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
