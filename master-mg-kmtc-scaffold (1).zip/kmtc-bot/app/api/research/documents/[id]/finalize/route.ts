import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { applyCorrections, buildRevisedDocx, type AcceptedCorrection } from "@/lib/research/apply-corrections";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: doc } = await supabase
    .from("research_documents")
    .select("id, extracted_text, original_filename")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (!doc || !doc.extracted_text) {
    return NextResponse.json({ error: "Document not found" }, { status: 404 });
  }

  const body = await req.json();
  const corrections: AcceptedCorrection[] = Array.isArray(body.corrections) ? body.corrections : [];

  const { revisedText, appliedCount, skipped } = applyCorrections(doc.extracted_text, corrections);

  const title = doc.original_filename.replace(/\.(docx|pdf)$/i, "") + " (Revised)";
  const buffer = await buildRevisedDocx(revisedText, title);

  const revisedPath = `${user.id}/revised-${crypto.randomUUID()}.docx`;
  const { error: uploadError } = await supabase.storage
    .from("research-documents")
    .upload(revisedPath, buffer, {
      contentType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    });

  if (uploadError) {
    return NextResponse.json({ error: `Could not save revised document: ${uploadError.message}` }, { status: 500 });
  }

  await supabase
    .from("research_documents")
    .update({ corrections, revised_storage_path: revisedPath, status: "finalized" })
    .eq("id", id);

  const { data: signed } = await supabase.storage
    .from("research-documents")
    .createSignedUrl(revisedPath, 300, { download: true });

  return NextResponse.json({
    downloadUrl: signed?.signedUrl ?? null,
    appliedCount,
    skippedCount: skipped.length,
  });
}
