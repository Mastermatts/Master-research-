import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { analyzeDocument, type CorrectionCategory } from "@/lib/ai/research";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data: doc } = await supabase
    .from("research_documents")
    .select("id, extracted_text")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (!doc) return NextResponse.json({ error: "Document not found" }, { status: 404 });
  if (!doc.extracted_text) return NextResponse.json({ error: "No extracted text to analyze" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const focusCategories: CorrectionCategory[] | undefined = Array.isArray(body.categories)
    ? body.categories
    : undefined;

  await supabase.from("research_documents").update({ status: "analyzing" }).eq("id", id);

  try {
    const { corrections, summary } = await analyzeDocument({ text: doc.extracted_text, focusCategories });

    const correctionsWithStatus = corrections.map((c) => ({ ...c, status: "pending" as const }));

    await supabase
      .from("research_documents")
      .update({
        corrections: correctionsWithStatus,
        selected_categories: focusCategories ?? [],
        status: "analyzed",
      })
      .eq("id", id);

    return NextResponse.json({ corrections: correctionsWithStatus, summary });
  } catch (err) {
    console.error("[research/documents/analyze]", err);
    await supabase.from("research_documents").update({ status: "uploaded" }).eq("id", id);
    return NextResponse.json({ error: "Analysis failed. Please try again." }, { status: 500 });
  }
}
