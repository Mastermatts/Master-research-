import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string; pageKey: string }> }
) {
  const { id, pageKey } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  // RLS already scopes this to the owner via the research_projects join, but
  // a clean 404 reads better than a silent no-op.
  const { data: project } = await supabase
    .from("research_projects")
    .select("id")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const body = await req.json();
  const update: Record<string, unknown> = { updated_at: new Date().toISOString() };
  if (typeof body.content === "string") update.content = body.content;
  if (typeof body.isComplete === "boolean") update.is_complete = body.isComplete;

  const { data, error } = await supabase
    .from("research_project_pages")
    .update(update)
    .eq("project_id", id)
    .eq("page_key", pageKey)
    .select("*")
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  // Mark the overall project as "building" the first time a page is saved.
  await supabase
    .from("research_projects")
    .update({ status: "building" })
    .eq("id", id)
    .eq("status", "topic_confirmed");

  return NextResponse.json({ page: data });
}
