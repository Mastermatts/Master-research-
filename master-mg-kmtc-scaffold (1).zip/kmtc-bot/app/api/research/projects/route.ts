import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { PRELIMINARY_PAGES } from "@/lib/research/preliminary-pages";

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const { data, error } = await supabase
    .from("research_projects")
    .select("id, path, topic_title, status, created_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ projects: data });
}

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const body = await req.json();
  const path = body.path === "generate" || body.path === "existing" ? body.path : null;
  const topic = body.topic;

  if (!path || !topic?.title?.trim()) {
    return NextResponse.json({ error: "path and a topic with a title are required" }, { status: 400 });
  }

  const { data: project, error } = await supabase
    .from("research_projects")
    .insert({
      user_id: user.id,
      path,
      programme: body.programme ?? null,
      research_area: body.researchArea ?? topic.researchArea ?? null,
      preferences: Array.isArray(body.preferences) ? body.preferences : null,
      topic_title: topic.title.trim(),
      target_population: topic.targetPopulation ?? null,
      study_setting: topic.studySetting ?? null,
      brief_explanation: topic.briefExplanation ?? null,
      feasibility_notes: topic.feasibilityConsiderations ?? null,
      status: "topic_confirmed",
    })
    .select("id")
    .single();

  if (error || !project) {
    return NextResponse.json({ error: error?.message || "Could not create project" }, { status: 500 });
  }

  const pageRows = PRELIMINARY_PAGES.map((p, i) => ({
    project_id: project.id,
    page_key: p.key,
    title: p.title,
    sort_order: i,
  }));

  const { error: pagesError } = await supabase.from("research_project_pages").insert(pageRows);
  if (pagesError) {
    console.error("[research/projects] page seed failed:", pagesError.message);
    // The project itself is still usable — the builder can re-seed missing pages on load if needed.
  }

  return NextResponse.json({ projectId: project.id }, { status: 201 });
}
