import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { refineTopic } from "@/lib/ai/research";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const body = await req.json();
  if (!body.topic || !body.instruction?.trim()) {
    return NextResponse.json({ error: "topic and instruction are required" }, { status: 400 });
  }

  try {
    const topic = await refineTopic({ topic: body.topic, instruction: body.instruction });
    return NextResponse.json({ topic });
  } catch (err) {
    console.error("[research/topics/refine]", err);
    return NextResponse.json({ error: "Could not refine the topic. Please try again." }, { status: 500 });
  }
}
