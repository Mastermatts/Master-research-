import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { generateTopics } from "@/lib/ai/research";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const body = await req.json();
  const programme = body.programme?.toString().trim();
  const researchArea = body.researchArea?.toString().trim();
  const preferences: string[] = Array.isArray(body.preferences) ? body.preferences : [];

  if (!programme || !researchArea) {
    return NextResponse.json({ error: "Programme and research area are required" }, { status: 400 });
  }

  try {
    const topics = await generateTopics({ programme, researchArea, preferences, count: 5 });
    return NextResponse.json({ topics });
  } catch (err) {
    console.error("[research/topics/generate]", err);
    return NextResponse.json({ error: "Could not generate topics. Please try again." }, { status: 500 });
  }
}
