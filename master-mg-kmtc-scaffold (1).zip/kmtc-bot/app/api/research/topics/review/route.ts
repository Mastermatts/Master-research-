import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { reviewTopic } from "@/lib/ai/research";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const body = await req.json();
  const topicText = body.topicText?.toString().trim();
  if (!topicText) {
    return NextResponse.json({ error: "topicText is required" }, { status: 400 });
  }

  try {
    const review = await reviewTopic(topicText);
    return NextResponse.json({ review });
  } catch (err) {
    console.error("[research/topics/review]", err);
    return NextResponse.json({ error: "Could not review the topic. Please try again." }, { status: 500 });
  }
}
