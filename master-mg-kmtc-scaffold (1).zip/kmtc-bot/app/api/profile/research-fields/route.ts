import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

type Body = {
  fieldId: string;
  value: string;
  step: number;      // combined step index across core + dynamic steps
  completed?: boolean;
};

export async function PATCH(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const body = (await req.json()) as Body;

  if (!body.fieldId) {
    return NextResponse.json({ error: "fieldId is required" }, { status: 400 });
  }
  if (typeof body.step !== "number" || body.step < 0) {
    return NextResponse.json({ error: "Invalid step" }, { status: 400 });
  }

  // Confirm the field exists and is currently active (an admin may have
  // deactivated it between page load and submit).
  const { data: field } = await supabase
    .from("research_profile_fields")
    .select("id")
    .eq("id", body.fieldId)
    .eq("is_active", true)
    .single();

  if (!field) {
    return NextResponse.json({ error: "This field is no longer part of the profile template" }, { status: 404 });
  }

  // Required-ness is enforced client-side for "Save & Next"; this endpoint
  // stays permissive (like the core-field endpoint) so "Save as draft &
  // continue later" can persist a required-but-incomplete field too.
  const value = body.value?.trim() || null;

  const { error: upsertError } = await supabase
    .from("student_research_profiles")
    .upsert(
      { user_id: user.id, field_id: body.fieldId, value },
      { onConflict: "user_id,field_id" }
    );

  if (upsertError) {
    return NextResponse.json({ error: upsertError.message }, { status: 500 });
  }

  // Onboarding progress lives on `profiles` regardless of which table the
  // answer itself was written to, so core and dynamic steps share one
  // resumable counter.
  const profileUpdate: Record<string, unknown> = {
    onboarding_step: body.step,
    updated_at: new Date().toISOString(),
  };
  if (body.completed) profileUpdate.onboarding_completed = true;

  const { error: profileError } = await supabase.from("profiles").update(profileUpdate).eq("id", user.id);
  if (profileError) {
    return NextResponse.json({ error: profileError.message }, { status: 500 });
  }

  return NextResponse.json({ saved: true });
}
