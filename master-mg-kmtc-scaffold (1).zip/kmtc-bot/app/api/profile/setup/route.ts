import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const ALLOWED_KEYS = ["full_name", "admission_number", "course", "department"] as const;
type AllowedKey = (typeof ALLOWED_KEYS)[number];

type Body = {
  key: AllowedKey;
  value: string;
  step: number; // which step index the student is now on (for resuming later)
  completed?: boolean; // true only when the final step is confirmed
};

export async function PATCH(req: NextRequest) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const body = (await req.json()) as Body;

  if (!ALLOWED_KEYS.includes(body.key)) {
    return NextResponse.json({ error: "Unknown field" }, { status: 400 });
  }
  if (typeof body.step !== "number" || body.step < 0) {
    return NextResponse.json({ error: "Invalid step" }, { status: 400 });
  }

  const update: Record<string, unknown> = {
    [body.key]: body.value?.trim() || null,
    onboarding_step: body.step,
    updated_at: new Date().toISOString(),
  };
  if (body.completed) update.onboarding_completed = true;

  const { data, error } = await supabase
    .from("profiles")
    .update(update)
    .eq("id", user.id)
    .select("full_name, admission_number, course, department, onboarding_step, onboarding_completed")
    .single();

  if (error) {
    if (error.code === "23505") {
      return NextResponse.json(
        { error: "That admission number is already registered to another account." },
        { status: 409 }
      );
    }
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ profile: data });
}

export async function GET() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  }

  const { data, error } = await supabase
    .from("profiles")
    .select("full_name, admission_number, course, department, onboarding_step, onboarding_completed")
    .eq("id", user.id)
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ profile: data });
}
