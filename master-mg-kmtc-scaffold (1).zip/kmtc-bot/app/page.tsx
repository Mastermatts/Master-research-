import Link from "next/link";
import { ArrowRight, BookOpen, Brain, MessageSquareText, NotebookPen } from "lucide-react";

const FEATURES = [
  {
    icon: Brain,
    title: "AI Medical Tutor",
    body: "Ask anything from Boyle's Law to the difference between sterilization and disinfection — get clear, exam-ready explanations.",
  },
  {
    icon: BookOpen,
    title: "Digital Library",
    body: "Notes, slides, manuals and past papers organized by department, from Anatomy to Public Health.",
  },
  {
    icon: NotebookPen,
    title: "AI Quiz Generator",
    body: "MCQs, case studies and practicals generated on demand, scored instantly with explanations.",
  },
  {
    icon: MessageSquareText,
    title: "Telegram Companion",
    body: "The same tutor, library and quizzes — right inside Telegram, wherever you're revising.",
  },
];

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-white">
      {/* Vitals-strip nav */}
      <header className="border-b border-medical-100">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <PulseMark />
            <span className="font-display text-lg font-bold text-medical-700">
              MASTER MG <span className="text-cyan">KMTC</span>
            </span>
          </div>
          <nav className="flex items-center gap-3">
            <Link href="/login" className="text-sm font-medium text-medical-700 hover:text-medical-500">
              Log in
            </Link>
            <Link href="/signup" className="btn-primary">
              Get started
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-6xl gap-10 px-6 py-20 lg:grid-cols-2 lg:items-center lg:py-28">
          <div>
            <p className="mb-4 inline-flex items-center rounded-full bg-medical-50 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-medical-600">
              Built for KMTC learners
            </p>
            <h1 className="font-display text-4xl font-extrabold leading-tight text-slate-900 sm:text-5xl">
              Your smart medical
              <br />
              learning <span className="text-medical-500">companion.</span>
            </h1>
            <p className="mt-5 max-w-lg text-base text-slate-600">
              One place for AI tutoring, revision notes, past papers and quizzes —
              built for KMTC and healthcare students across Kenya, on the web
              and on Telegram.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/signup" className="btn-primary gap-2">
                Start learning free <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="https://t.me" className="btn-secondary">
                Open Telegram bot
              </Link>
            </div>
          </div>

          {/* Signature: an ECG/vitals line that resolves into a rising study-streak graph */}
          <VitalsPanel />
        </div>
      </section>

      {/* Features */}
      <section className="border-t border-medical-100 bg-medical-50/40">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <h2 className="font-display text-2xl font-bold text-slate-900">
            Everything on your revision list, in one place
          </h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map(({ icon: Icon, title, body }) => (
              <div key={title} className="glass rounded-xl2 p-5">
                <Icon className="h-6 w-6 text-medical-500" />
                <h3 className="mt-3 font-display font-semibold text-slate-900">{title}</h3>
                <p className="mt-2 text-sm text-slate-600">{body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-medical-100">
        <div className="mx-auto max-w-6xl px-6 py-8 text-sm text-slate-500">
          © {new Date().getFullYear()} Master MG KMTC AI Learning Bot.
        </div>
      </footer>
    </main>
  );
}

function PulseMark() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
      <circle cx="14" cy="14" r="14" fill="#0077B6" />
      <path
        d="M4 14H9L11.5 8L15.5 20L18 14H24"
        stroke="#00B4D8"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function VitalsPanel() {
  return (
    <div className="glass relative rounded-xl2 p-6">
      <div className="mb-4 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-medical-600">
          Weekly study vitals
        </span>
        <span className="inline-flex items-center gap-1 text-xs font-medium text-accent">
          <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Streak: 12 days
        </span>
      </div>
      <svg viewBox="0 0 400 160" className="w-full" role="img" aria-label="Rising study streak trend">
        <defs>
          <linearGradient id="vitalsFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00B4D8" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#00B4D8" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M0 120 L40 120 L55 60 L70 140 L85 100 L110 100 L130 40 L150 100 L400 100"
          fill="none"
          stroke="#0077B6"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M150 100 C 220 95, 280 55, 400 20"
          fill="none"
          stroke="#2ECC71"
          strokeWidth="2.5"
          strokeLinecap="round"
        />
        <path
          d="M150 100 C 220 95, 280 55, 400 20 L400 160 L0 160 L0 120 L40 120 L55 60 L70 140 L85 100 L110 100 L130 40 L150 100 Z"
          fill="url(#vitalsFill)"
          stroke="none"
        />
      </svg>
      <div className="mt-3 grid grid-cols-3 gap-3 text-center">
        <Stat label="Quizzes" value="34" />
        <Stat label="Notes read" value="128" />
        <Stat label="Avg. score" value="82%" />
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-white/70 py-2">
      <div className="font-display text-lg font-bold text-medical-700">{value}</div>
      <div className="text-[11px] text-slate-500">{label}</div>
    </div>
  );
}
