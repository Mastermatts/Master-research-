import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ProfileWizard, { type WizardStep } from "./profile-wizard";

const CORE_STEPS: WizardStep[] = [
  { key: "full_name", kind: "core", label: "Full Name", type: "text", placeholder: "e.g. John Witidia", required: true },
  {
    key: "admission_number",
    kind: "core",
    label: "Admission Number",
    type: "text",
    placeholder: "e.g. DMET/24/001/107",
    required: true,
  },
  {
    key: "course",
    kind: "core",
    label: "Course / Programme",
    type: "text",
    placeholder: "e.g. Medical Engineering",
    required: true,
  },
  {
    key: "department",
    kind: "core",
    label: "Department",
    type: "select",
    options: [
      "Medicine",
      "Nursing",
      "Clinical Medicine",
      "Medical Engineering",
      "Public Health",
      "Health Records",
      "Nutrition",
    ],
    required: true,
  },
];

export default async function OnboardingPage({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string }>;
}) {
  const { edit } = await searchParams;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, admission_number, course, department, onboarding_step, onboarding_completed")
    .eq("id", user.id)
    .single();

  const { data: activeFields } = await supabase
    .from("research_profile_fields")
    .select("id, key, label, field_type, options, placeholder, helper_text, is_required, sort_order")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  const { data: savedAnswers } = await supabase
    .from("student_research_profiles")
    .select("field_id, value")
    .eq("user_id", user.id);

  const answerByFieldId = new Map((savedAnswers ?? []).map((a) => [a.field_id, a.value ?? ""]));

  const dynamicSteps: WizardStep[] = (activeFields ?? []).map((f) => ({
    key: f.key,
    kind: "dynamic",
    fieldId: f.id,
    label: f.label,
    type: f.field_type as WizardStep["type"],
    options: (f.options as string[] | null) ?? undefined,
    placeholder: f.placeholder ?? undefined,
    helperText: f.helper_text ?? undefined,
    required: f.is_required,
  }));

  const steps = [...CORE_STEPS, ...dynamicSteps];

  const initialValues: Record<string, string> = {
    full_name: profile?.full_name ?? "",
    admission_number: profile?.admission_number ?? "",
    course: profile?.course ?? "",
    department: profile?.department ?? "",
  };
  for (const f of activeFields ?? []) {
    initialValues[f.key] = answerByFieldId.get(f.id) ?? "";
  }

  // Already finished? Move on, unless they came here on purpose to edit.
  if (profile?.onboarding_completed && edit !== "1") {
    redirect("/dashboard");
  }

  const initialStep = profile?.onboarding_completed ? steps.length - 1 : profile?.onboarding_step ?? 0;

  return <ProfileWizard steps={steps} initialValues={initialValues} initialStep={initialStep} />;
}
