"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Check, CheckCircle2, Pencil, Save } from "lucide-react";

export type WizardStep = {
  key: string;
  kind: "core" | "dynamic";
  fieldId?: string; // only for kind === "dynamic"
  label: string;
  type: "text" | "textarea" | "select" | "date";
  options?: string[];
  placeholder?: string;
  helperText?: string;
  required: boolean;
};

type Values = Record<string, string>;

export default function ProfileWizard({
  steps,
  initialValues,
  initialStep,
}: {
  steps: WizardStep[];
  initialValues: Values;
  initialStep: number;
}) {
  const router = useRouter();
  const [values, setValues] = useState<Values>(initialValues);
  const [stepIndex, setStepIndex] = useState(() => Math.min(Math.max(initialStep, 0), steps.length - 1));
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState<"next" | "draft" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [finished, setFinished] = useState(initialStep >= steps.length);

  const activeStep = steps[stepIndex];
  const [loadedStepKey, setLoadedStepKey] = useState<string | null>(null);
  if (activeStep && loadedStepKey !== activeStep.key) {
    setDraft(values[activeStep.key] ?? "");
    setLoadedStepKey(activeStep.key);
  }

  const isLastStep = stepIndex === steps.length - 1;
  const visibleSteps = steps.slice(0, stepIndex + 1);

  function goToStep(index: number) {
    setError(null);
    setFinished(false);
    setStepIndex(index);
    setLoadedStepKey(null); // forces draft to reload from `values` on next render
  }

  async function persist(step: WizardStep, value: string, stepNumber: number, completed: boolean) {
    if (step.kind === "core") {
      const res = await fetch("/api/profile/setup", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key: step.key, value, step: stepNumber, completed }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not save your profile");
      return data;
    }

    const res = await fetch("/api/profile/research-fields", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fieldId: step.fieldId, value, step: stepNumber, completed }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Could not save your profile");
    return data;
  }

  async function handleSaveAndNext() {
    if (!activeStep) return;
    const trimmed = draft.trim();
    if (activeStep.required && !trimmed) {
      setError(`${activeStep.label} is required.`);
      return;
    }

    setSaving("next");
    setError(null);
    try {
      const willComplete = isLastStep;
      await persist(activeStep, trimmed, Math.min(stepIndex + 1, steps.length), willComplete);
      setValues((prev) => ({ ...prev, [activeStep.key]: trimmed }));

      if (willComplete) {
        setFinished(true);
        setTimeout(() => router.push("/dashboard"), 900);
      } else {
        goToStep(stepIndex + 1);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSaving(null);
    }
  }

  function handleBack() {
    if (stepIndex === 0) return;
    goToStep(stepIndex - 1);
  }

  async function handleSaveDraftAndExit() {
    if (!activeStep) return;
    setSaving("draft");
    setError(null);
    try {
      // Draft save skips the "required" check — whatever's typed so far is
      // kept, even if blank, so the student can leave mid-field.
      await persist(activeStep, draft.trim(), stepIndex, false);
      setValues((prev) => ({ ...prev, [activeStep.key]: draft.trim() }));
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save your draft.");
      setSaving(null);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-medical-50/40 px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <h1 className="font-display text-2xl font-bold text-slate-900">
            {finished ? "You're all set!" : "Build your research profile"}
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            {finished ? "Taking you to your dashboard…" : `Step ${stepIndex + 1} of ${steps.length}`}
          </p>
          {!finished && (
            <div className="mx-auto mt-3 flex max-w-xs flex-wrap justify-center gap-1">
              {steps.map((s, i) => (
                <div
                  key={s.key}
                  className={`h-1.5 w-4 rounded-full transition-colors ${
                    i <= stepIndex ? "bg-medical-500" : "bg-medical-100"
                  }`}
                />
              ))}
            </div>
          )}
        </div>

        {finished ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass flex flex-col items-center gap-3 rounded-xl2 p-10 text-center"
          >
            <CheckCircle2 className="h-12 w-12 text-accent" />
            <p className="text-sm text-slate-600">Your profile is complete.</p>
          </motion.div>
        ) : (
          <motion.div layout className="space-y-3">
            {/* Completed steps stack upward as each one is confirmed */}
            <AnimatePresence initial={false}>
              {visibleSteps.slice(0, -1).map((step, i) => {
                const val = values[step.key];
                if (!val) return null; // optional steps the student skipped don't clutter the stack
                return (
                  <motion.button
                    key={step.key}
                    layout
                    type="button"
                    onClick={() => goToStep(i)}
                    initial={{ opacity: 0, y: 24 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ type: "spring", stiffness: 300, damping: 28 }}
                    className="glass flex w-full items-center justify-between gap-3 rounded-xl p-3.5 text-left"
                  >
                    <div className="flex items-center gap-3 overflow-hidden">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent/15 text-accent">
                        <Check className="h-3.5 w-3.5" />
                      </span>
                      <div className="overflow-hidden">
                        <div className="text-[11px] font-medium uppercase tracking-wide text-slate-400">
                          {step.label}
                        </div>
                        <div className="truncate text-sm font-semibold text-slate-800">{val}</div>
                      </div>
                    </div>
                    <Pencil className="h-4 w-4 shrink-0 text-medical-400" />
                  </motion.button>
                );
              })}
            </AnimatePresence>

            {/* Active step */}
            <motion.div layout className="glass rounded-xl2 p-5">
              <label className="mb-1 block text-sm font-semibold text-slate-800">
                {activeStep.label}
                {!activeStep.required && <span className="ml-1 text-xs font-normal text-slate-400">(optional)</span>}
              </label>
              {activeStep.helperText && <p className="mb-2 text-xs text-slate-500">{activeStep.helperText}</p>}

              {activeStep.type === "select" ? (
                <select value={draft} onChange={(e) => setDraft(e.target.value)} className="input-field" autoFocus>
                  <option value="" disabled>
                    {activeStep.placeholder ?? "Select..."}
                  </option>
                  {activeStep.options?.map((opt) => (
                    <option key={opt} value={opt}>
                      {opt}
                    </option>
                  ))}
                </select>
              ) : activeStep.type === "textarea" ? (
                <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={activeStep.placeholder}
                  className="input-field"
                  rows={3}
                  autoFocus
                />
              ) : activeStep.type === "date" ? (
                <input
                  type="date"
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  className="input-field"
                  autoFocus
                />
              ) : (
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder={activeStep.placeholder}
                  className="input-field"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleSaveAndNext();
                    }
                  }}
                />
              )}

              {error && <p className="mt-2 text-sm text-red-600">{error}</p>}

              <div className="mt-5 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleBack}
                  disabled={stepIndex === 0 || saving !== null}
                  className="inline-flex items-center gap-1 text-sm font-semibold text-medical-600 disabled:opacity-30"
                >
                  <ArrowLeft className="h-4 w-4" /> BACK
                </button>
                <button type="button" onClick={handleSaveAndNext} disabled={saving !== null} className="btn-primary">
                  {saving === "next"
                    ? "Saving…"
                    : !activeStep.required && !draft.trim()
                      ? isLastStep
                        ? "SKIP & FINISH →"
                        : "SKIP →"
                      : isLastStep
                        ? "SAVE & FINISH →"
                        : "SAVE & NEXT →"}
                </button>
              </div>
            </motion.div>

            <div className="text-center">
              <button
                type="button"
                onClick={handleSaveDraftAndExit}
                disabled={saving !== null}
                className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-medical-600"
              >
                <Save className="h-3.5 w-3.5" />
                {saving === "draft" ? "Saving draft…" : "Save as draft & continue later"}
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </main>
  );
}
