"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ArrowDown,
  ArrowUp,
  Eye,
  EyeOff,
  Loader2,
  Plus,
  Trash2,
  X,
} from "lucide-react";

type FieldType = "text" | "textarea" | "select" | "date";

type Field = {
  id: string;
  key: string;
  label: string;
  field_type: FieldType;
  options: string[] | null;
  placeholder: string | null;
  helper_text: string | null;
  is_required: boolean;
  sort_order: number;
  is_active: boolean;
};

const FIELD_TYPE_LABELS: Record<FieldType, string> = {
  text: "Short text",
  textarea: "Long text",
  select: "Dropdown",
  date: "Date",
};

export default function FieldsManager({ initialFields }: { initialFields: Field[] }) {
  const [fields, setFields] = useState<Field[]>(initialFields);
  const [error, setError] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function patchField(id: string, body: Partial<Field>) {
    setBusyId(id);
    setError(null);
    try {
      const res = await fetch(`/api/admin/research-fields/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Update failed");
      setFields((prev) => prev.map((f) => (f.id === id ? data.field : f)).sort((a, b) => a.sort_order - b.sort_order));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusyId(null);
    }
  }

  async function toggleActive(field: Field) {
    await patchField(field.id, { is_active: !field.is_active });
  }

  async function toggleRequired(field: Field) {
    await patchField(field.id, { is_required: !field.is_required });
  }

  async function move(field: Field, direction: -1 | 1) {
    const sorted = [...fields].sort((a, b) => a.sort_order - b.sort_order);
    const idx = sorted.findIndex((f) => f.id === field.id);
    const swapWith = sorted[idx + direction];
    if (!swapWith) return;
    await Promise.all([
      patchField(field.id, { sort_order: swapWith.sort_order }),
      patchField(swapWith.id, { sort_order: field.sort_order }),
    ]);
  }

  async function deleteField(field: Field) {
    if (
      !confirm(
        `Delete "${field.label}"? This also permanently removes every student's saved answer for it. Consider hiding it instead.`
      )
    ) {
      return;
    }
    setBusyId(field.id);
    setError(null);
    try {
      const res = await fetch(`/api/admin/research-fields/${field.id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Delete failed");
      setFields((prev) => prev.filter((f) => f.id !== field.id));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusyId(null);
    }
  }

  const sorted = [...fields].sort((a, b) => a.sort_order - b.sort_order);

  return (
    <main className="min-h-screen bg-medical-50/40 px-6 py-10">
      <div className="mx-auto max-w-3xl">
        <Link href="/dashboard" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>
        <div className="mt-1 flex items-center justify-between">
          <div>
            <h1 className="font-display text-xl font-bold text-slate-900">Research Profile Template</h1>
            <p className="text-sm text-slate-600">
              Steps 5–13 of the student onboarding wizard. Full Name, Admission Number, Course and
              Department (steps 1–4) are fixed account fields and aren&apos;t editable here.
            </p>
          </div>
          <button onClick={() => setAddOpen(true)} className="btn-primary shrink-0 gap-2">
            <Plus className="h-4 w-4" /> Add field
          </button>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            {error}
          </div>
        )}

        <div className="mt-6 space-y-2">
          {sorted.map((field, i) => (
            <div
              key={field.id}
              className={`glass flex items-center gap-3 rounded-xl2 p-4 ${!field.is_active ? "opacity-50" : ""}`}
            >
              <div className="flex flex-col">
                <button
                  onClick={() => move(field, -1)}
                  disabled={i === 0 || busyId === field.id}
                  className="text-slate-400 hover:text-medical-600 disabled:opacity-20"
                  aria-label="Move up"
                >
                  <ArrowUp className="h-4 w-4" />
                </button>
                <button
                  onClick={() => move(field, 1)}
                  disabled={i === sorted.length - 1 || busyId === field.id}
                  className="text-slate-400 hover:text-medical-600 disabled:opacity-20"
                  aria-label="Move down"
                >
                  <ArrowDown className="h-4 w-4" />
                </button>
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-medical-500">
                    Step {5 + i}
                  </span>
                  <span className="rounded-full bg-medical-50 px-2 py-0.5 text-[11px] text-medical-700">
                    {FIELD_TYPE_LABELS[field.field_type]}
                  </span>
                  {!field.is_required && (
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-500">optional</span>
                  )}
                </div>
                <div className="truncate font-medium text-slate-900">{field.label}</div>
                <div className="truncate text-xs text-slate-400">key: {field.key}</div>
              </div>

              <div className="flex shrink-0 items-center gap-1">
                <button
                  onClick={() => toggleRequired(field)}
                  disabled={busyId === field.id}
                  className="btn-secondary px-2.5 py-1.5 text-xs"
                  title="Toggle required"
                >
                  {field.is_required ? "Required" : "Optional"}
                </button>
                <button
                  onClick={() => toggleActive(field)}
                  disabled={busyId === field.id}
                  className="btn-secondary px-2.5 py-1.5 text-xs"
                  title={field.is_active ? "Hide from wizard" : "Show in wizard"}
                >
                  {busyId === field.id ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : field.is_active ? (
                    <Eye className="h-3.5 w-3.5" />
                  ) : (
                    <EyeOff className="h-3.5 w-3.5" />
                  )}
                </button>
                <button
                  onClick={() => deleteField(field)}
                  disabled={busyId === field.id}
                  className="rounded-lg p-1.5 text-red-500 hover:bg-red-50"
                  title="Delete permanently"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}

          {sorted.length === 0 && (
            <div className="glass rounded-xl2 p-8 text-center text-sm text-slate-500">
              No research profile fields yet — add the first one.
            </div>
          )}
        </div>
      </div>

      {addOpen && (
        <AddFieldModal
          onClose={() => setAddOpen(false)}
          onCreated={(field) => {
            setFields((prev) => [...prev, field]);
            setAddOpen(false);
          }}
        />
      )}
    </main>
  );
}

function AddFieldModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (field: Field) => void;
}) {
  const [label, setLabel] = useState("");
  const [fieldType, setFieldType] = useState<FieldType>("text");
  const [optionsText, setOptionsText] = useState("");
  const [placeholder, setPlaceholder] = useState("");
  const [helperText, setHelperText] = useState("");
  const [isRequired, setIsRequired] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!label.trim()) {
      setError("Label is required");
      return;
    }
    setSubmitting(true);
    setError(null);

    const key = label
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "");

    const options =
      fieldType === "select"
        ? optionsText
            .split("\n")
            .map((o) => o.trim())
            .filter(Boolean)
        : undefined;

    try {
      const res = await fetch("/api/admin/research-fields", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          key,
          label: label.trim(),
          fieldType,
          options,
          placeholder: placeholder.trim() || null,
          helperText: helperText.trim() || null,
          isRequired,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not create field");
      onCreated(data.field);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 px-4">
      <div className="glass w-full max-w-md rounded-xl2 bg-white p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-slate-900">Add research profile field</h2>
          <button onClick={onClose} aria-label="Close">
            <X className="h-5 w-5 text-slate-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            required
            placeholder="Label, e.g. Ethics Approval Number"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            className="input-field"
          />
          <select value={fieldType} onChange={(e) => setFieldType(e.target.value as FieldType)} className="input-field">
            {Object.entries(FIELD_TYPE_LABELS).map(([value, l]) => (
              <option key={value} value={value}>
                {l}
              </option>
            ))}
          </select>
          {fieldType === "select" && (
            <textarea
              required
              placeholder={"One option per line, e.g.\nNairobi\nMombasa\nEldoret"}
              value={optionsText}
              onChange={(e) => setOptionsText(e.target.value)}
              className="input-field"
              rows={3}
            />
          )}
          <input
            placeholder="Placeholder text (optional)"
            value={placeholder}
            onChange={(e) => setPlaceholder(e.target.value)}
            className="input-field"
          />
          <input
            placeholder="Helper text shown under the label (optional)"
            value={helperText}
            onChange={(e) => setHelperText(e.target.value)}
            className="input-field"
          />
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" checked={isRequired} onChange={(e) => setIsRequired(e.target.checked)} />
            Required
          </label>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button type="submit" disabled={submitting} className="btn-primary w-full">
            {submitting ? "Adding…" : "Add field"}
          </button>
        </form>
      </div>
    </div>
  );
}
