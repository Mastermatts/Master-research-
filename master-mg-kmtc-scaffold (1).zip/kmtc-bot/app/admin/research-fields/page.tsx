import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getUserRole } from "@/lib/auth/roles";
import FieldsManager from "./fields-manager";

export default async function AdminResearchFieldsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const role = await getUserRole(supabase, user.id);
  if (role !== "admin") redirect("/dashboard");

  const { data: fields } = await supabase
    .from("research_profile_fields")
    .select("*")
    .order("sort_order", { ascending: true });

  return <FieldsManager initialFields={fields ?? []} />;
}
