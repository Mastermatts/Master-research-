import { redirect } from "next/navigation";
import Link from "next/link";
import { BookOpen, FlaskConical, Pencil, Settings, Sparkles } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import SignOutButton from "./sign-out-button";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, department, course, admission_number, streak_count, subscription_tier, role")
    .eq("id", user.id)
    .single();

  return (
    <main className="min-h-screen bg-medical-50/40 px-6 py-10">
      <div className="mx-auto max-w-4xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-900">
              Welcome back{profile?.full_name ? `, ${profile.full_name.split(" ")[0]}` : ""} 👋
            </h1>
            <p className="text-sm text-slate-600">
              {profile?.course ?? "Set your course to personalize your feed."}
              {profile?.department ? ` · ${profile.department}` : ""}
              {profile?.admission_number ? ` · ${profile.admission_number}` : ""}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {profile?.role === "admin" && (
              <Link
                href="/admin/research-fields"
                className="inline-flex items-center gap-1 text-sm font-medium text-medical-600 hover:underline"
              >
                <Settings className="h-3.5 w-3.5" /> Research template
              </Link>
            )}
            <Link
              href="/onboarding?edit=1"
              className="inline-flex items-center gap-1 text-sm font-medium text-medical-600 hover:underline"
            >
              <Pencil className="h-3.5 w-3.5" /> Edit profile
            </Link>
            <SignOutButton />
          </div>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          <Link
            href="/dashboard/tutor"
            className="flex items-center justify-between rounded-xl2 bg-medical-500 px-6 py-5 text-white shadow-lg shadow-medical-500/20 transition-transform hover:-translate-y-0.5"
          >
            <div className="flex items-center gap-3">
              <Sparkles className="h-6 w-6" />
              <div>
                <div className="font-display font-semibold">AI Medical Tutor</div>
                <div className="text-sm text-white/80">Explanations, mnemonics, revision notes.</div>
              </div>
            </div>
          </Link>

          <Link
            href="/dashboard/library"
            className="flex items-center justify-between rounded-xl2 bg-cyan px-6 py-5 text-white shadow-lg shadow-cyan/20 transition-transform hover:-translate-y-0.5"
          >
            <div className="flex items-center gap-3">
              <BookOpen className="h-6 w-6" />
              <div>
                <div className="font-display font-semibold">Digital Library</div>
                <div className="text-sm text-white/80">Notes, books, slides and past papers.</div>
              </div>
            </div>
          </Link>

          <Link
            href="/dashboard/research"
            className="flex items-center justify-between rounded-xl2 bg-accent px-6 py-5 text-white shadow-lg shadow-accent/20 transition-transform hover:-translate-y-0.5"
          >
            <div className="flex items-center gap-3">
              <FlaskConical className="h-6 w-6" />
              <div>
                <div className="font-display font-semibold">Research Project</div>
                <div className="text-sm text-white/80">Find a topic, review one, or fix a document.</div>
              </div>
            </div>
          </Link>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          <div className="glass rounded-xl2 p-5">
            <div className="text-xs font-semibold uppercase tracking-wide text-medical-600">Streak</div>
            <div className="mt-1 font-display text-2xl font-bold text-slate-900">
              {profile?.streak_count ?? 0} days
            </div>
          </div>
          <div className="glass rounded-xl2 p-5">
            <div className="text-xs font-semibold uppercase tracking-wide text-medical-600">Plan</div>
            <div className="mt-1 font-display text-2xl font-bold capitalize text-slate-900">
              {profile?.subscription_tier ?? "free"}
            </div>
          </div>
          <div className="glass rounded-xl2 p-5">
            <div className="text-xs font-semibold uppercase tracking-wide text-medical-600">Next up</div>
            <div className="mt-1 text-sm text-slate-700">AI Tutor, Library and Quizzes ship next.</div>
          </div>
        </div>
      </div>
    </main>
  );
}
