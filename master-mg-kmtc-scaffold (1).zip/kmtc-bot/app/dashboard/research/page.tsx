import { redirect } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, FileSearch, Lightbulb, PenLine } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

const PATHS = [
  {
    href: "/dashboard/research/generate",
    icon: Lightbulb,
    title: "I don't have a research topic",
    body: "Tell us your programme and area of interest — we'll generate several feasible topic ideas to choose from.",
    cta: "Generate topics",
    color: "bg-medical-500 shadow-medical-500/20",
  },
  {
    href: "/dashboard/research/existing",
    icon: PenLine,
    title: "I already have a research topic",
    body: "Enter your topic and get AI feedback on clarity, scope, and feasibility before you commit to it.",
    cta: "Enter my topic",
    color: "bg-cyan shadow-cyan/20",
  },
  {
    href: "/dashboard/research/document",
    icon: FileSearch,
    title: "I already have a research document",
    body: "Upload your DOCX or PDF for an AI-assisted review — grammar, clarity, structure, and a hallucination check.",
    cta: "Upload document",
    color: "bg-accent shadow-accent/20",
  },
];

export default async function ResearchHomePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: projects } = await supabase
    .from("research_projects")
    .select("id, topic_title, status")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(3);

  return (
    <main className="min-h-screen bg-medical-50/40 px-6 py-10">
      <div className="mx-auto max-w-4xl">
        <Link href="/dashboard" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>
        <h1 className="mt-1 font-display text-2xl font-bold text-slate-900">Research Project</h1>
        <p className="text-sm text-slate-600">Where are you starting from?</p>

        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          {PATHS.map(({ href, icon: Icon, title, body, cta, color }) => (
            <Link key={href} href={href} className="glass flex flex-col rounded-xl2 p-5 transition-transform hover:-translate-y-0.5">
              <div className={`mb-3 flex h-10 w-10 items-center justify-center rounded-xl text-white shadow-lg ${color}`}>
                <Icon className="h-5 w-5" />
              </div>
              <h2 className="font-display font-semibold text-slate-900">{title}</h2>
              <p className="mt-1 flex-1 text-sm text-slate-600">{body}</p>
              <span className="mt-4 text-sm font-semibold text-medical-600">{cta} →</span>
            </Link>
          ))}
        </div>

        {projects && projects.length > 0 && (
          <div className="mt-10">
            <h3 className="mb-3 text-sm font-semibold text-slate-700">Continue an existing project</h3>
            <div className="space-y-2">
              {projects.map((p) => (
                <Link
                  key={p.id}
                  href={
                    p.status === "draft"
                      ? "/dashboard/research"
                      : `/dashboard/research/builder/${p.id}`
                  }
                  className="glass flex items-center justify-between rounded-xl p-4"
                >
                  <div>
                    <div className="font-medium text-slate-900">{p.topic_title || "Untitled project"}</div>
                    <div className="text-xs capitalize text-slate-500">{p.status.replace("_", " ")}</div>
                  </div>
                  <span className="text-sm font-semibold text-medical-600">Open →</span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
