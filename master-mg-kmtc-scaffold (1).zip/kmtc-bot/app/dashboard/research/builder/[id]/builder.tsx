"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowLeft, Check, Loader2 } from "lucide-react";
import { PRELIMINARY_PAGES } from "@/lib/research/preliminary-pages";

type Page = {
  id: string;
  page_key: string;
  title: string;
  content: string;
  is_complete: boolean;
  sort_order: number;
};

export default function Builder({
  projectId,
  topicTitle,
  pages: initialPages,
}: {
  projectId: string;
  topicTitle: string;
  pages: Page[];
}) {
  const [pages, setPages] = useState<Page[]>(initialPages);
  const [activeIndex, setActiveIndex] = useState(() => {
    const firstIncomplete = initialPages.findIndex((p) => !p.is_complete);
    return firstIncomplete === -1 ? 0 : firstIncomplete;
  });
  const [draft, setDraft] = useState(initialPages[activeIndex]?.content ?? "");
  const [saving, setSaving] = useState(false);

  const active = pages[activeIndex];
  const completedCount = pages.filter((p) => p.is_complete).length;
  const hint = PRELIMINARY_PAGES.find((p) => p.key === active?.page_key)?.hint;

  function goTo(index: number) {
    setActiveIndex(index);
    setDraft(pages[index]?.content ?? "");
  }

  async function save(markComplete: boolean) {
    if (!active) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/research/projects/${projectId}/pages/${active.page_key}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: draft, isComplete: markComplete ? true : active.is_complete }),
      });
      const data = await res.json();
      if (res.ok) {
        setPages((prev) => prev.map((p) => (p.page_key === active.page_key ? data.page : p)));
        if (markComplete && activeIndex < pages.length - 1) {
          goTo(activeIndex + 1);
        }
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="min-h-screen bg-medical-50/40">
      <header className="border-b border-medical-100 bg-white/70 px-6 py-4">
        <Link href="/dashboard/research" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Research paths
        </Link>
        <h1 className="font-display text-lg font-bold text-slate-900">{topicTitle || "Research Builder"}</h1>
        <p className="text-xs text-slate-500">
          Preliminary pages · {completedCount}/{pages.length} complete
        </p>
      </header>

      <div className="mx-auto flex max-w-5xl gap-6 px-6 py-8">
        <aside className="hidden w-56 shrink-0 space-y-1 md:block">
          {pages.map((p, i) => (
            <button
              key={p.page_key}
              onClick={() => goTo(i)}
              className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm ${
                i === activeIndex ? "bg-medical-500 text-white" : "text-slate-600 hover:bg-medical-50"
              }`}
            >
              <span
                className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[10px] ${
                  p.is_complete
                    ? "bg-accent text-white"
                    : i === activeIndex
                      ? "bg-white/20 text-white"
                      : "border border-slate-300 text-slate-400"
                }`}
              >
                {p.is_complete ? <Check className="h-2.5 w-2.5" /> : i + 1}
              </span>
              <span className="truncate">{p.title}</span>
            </button>
          ))}
        </aside>

        {active && (
          <div className="glass flex-1 rounded-xl2 p-6">
            <h2 className="font-display text-lg font-bold text-slate-900">{active.title}</h2>
            {hint && <p className="mt-1 text-sm text-slate-500">{hint}</p>}

            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={12}
              placeholder={`Write your ${active.title.toLowerCase()} here...`}
              className="input-field mt-4 font-mono text-sm"
            />

            <div className="mt-5 flex items-center justify-between">
              <button
                onClick={() => goTo(Math.max(0, activeIndex - 1))}
                disabled={activeIndex === 0}
                className="btn-secondary disabled:opacity-40"
              >
                ← Previous
              </button>
              <div className="flex gap-2">
                <button onClick={() => save(false)} disabled={saving} className="btn-secondary">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save draft"}
                </button>
                <button onClick={() => save(true)} disabled={saving} className="btn-primary">
                  {activeIndex === pages.length - 1 ? "Mark complete" : "Save & next →"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
