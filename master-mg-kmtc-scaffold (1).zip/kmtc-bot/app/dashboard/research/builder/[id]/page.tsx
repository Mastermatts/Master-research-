import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import Builder from "./builder";

export default async function ResearchBuilderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: project } = await supabase
    .from("research_projects")
    .select("id, topic_title, brief_explanation, status")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (!project) notFound();

  const { data: pages } = await supabase
    .from("research_project_pages")
    .select("id, page_key, title, content, is_complete, sort_order")
    .eq("project_id", id)
    .order("sort_order", { ascending: true });

  return <Builder projectId={project.id} topicTitle={project.topic_title ?? ""} pages={pages ?? []} />;
}
