"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Loader2, RefreshCw, Sparkles } from "lucide-react";

type TopicSuggestion = {
  title: string;
  researchArea: string;
  targetPopulation: string;
  studySetting: string;
  briefExplanation: string;
  feasibilityConsiderations: string;
};

const PREFERENCE_OPTIONS = [
  "Hospital/health facility",
  "Community",
  "Healthcare workers",
  "Patients",
  "Equipment maintenance",
  "Patient safety",
  "Technology",
  "Equipment management",
];

export default function GenerateFlow({ defaultProgramme }: { defaultProgramme: string }) {
  const router = useRouter();
  const [stage, setStage] = useState<"form" | "results" | "confirm">("form");

  const [programme, setProgramme] = useState(defaultProgramme);
  const [researchArea, setResearchArea] = useState("");
  const [preferences, setPreferences] = useState<string[]>([]);

  const [topics, setTopics] = useState<TopicSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [chosen, setChosen] = useState<TopicSuggestion | null>(null);
  const [refineOpenFor, setRefineOpenFor] = useState<number | null>(null);
  const [refineText, setRefineText] = useState("");
  const [refining, setRefining] = useState<number | null>(null);
  const [confirming, setConfirming] = useState(false);

  function togglePreference(p: string) {
    setPreferences((prev) => (prev.includes(p) ? prev.filter((x) => x !== p) : [...prev, p]));
  }

  async function handleGenerate(e?: React.FormEvent) {
    e?.preventDefault();
    if (!programme.trim() || !researchArea.trim()) {
      setError("Programme and research area are required.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/research/topics/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ programme, researchArea, preferences }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not generate topics");
      setTopics(data.topics);
      setStage("results");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  async function handleRefine(index: number) {
    if (!refineText.trim()) return;
    setRefining(index);
    setError(null);
    try {
      const res = await fetch("/api/research/topics/refine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: topics[index], instruction: refineText }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not refine topic");
      setTopics((prev) => prev.map((t, i) => (i === index ? data.topic : t)));
      if (chosen && refineOpenFor === index) setChosen(data.topic);
      setRefineOpenFor(null);
      setRefineText("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setRefining(null);
    }
  }

  function selectTopic(topic: TopicSuggestion) {
    setChosen(topic);
    setStage("confirm");
  }

  async function confirmTopic() {
    if (!chosen) return;
    setConfirming(true);
    setError(null);
    try {
      const res = await fetch("/api/research/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: "generate", programme, researchArea, preferences, topic: chosen }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not confirm topic");
      router.push(`/dashboard/research/builder/${data.projectId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
      setConfirming(false);
    }
  }

  return (
    <main className="min-h-screen bg-medical-50/40 px-6 py-10">
      <div className="mx-auto max-w-4xl">
        <Link href="/dashboard/research" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Research paths
        </Link>
        <h1 className="mt-1 font-display text-2xl font-bold text-slate-900">Find a research topic</h1>

        {error && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
        )}

        {stage === "form" && (
          <form onSubmit={handleGenerate} className="glass mt-6 max-w-lg space-y-4 rounded-xl2 p-6">
            <div>
              <label className="mb-1 block text-sm font-semibold text-slate-800">Programme</label>
              <input
                required
                value={programme}
                onChange={(e) => setProgramme(e.target.value)}
                placeholder="e.g. Medical Engineering"
                className="input-field"
              />
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-slate-800">Research Area</label>
              <input
                required
                value={researchArea}
                onChange={(e) => setResearchArea(e.target.value)}
                placeholder="e.g. Medical equipment"
                className="input-field"
              />
            </div>
            <div>
              <label className="mb-2 block text-sm font-semibold text-slate-800">Optional preferences</label>
              <div className="flex flex-wrap gap-2">
                {PREFERENCE_OPTIONS.map((p) => (
                  <button
                    type="button"
                    key={p}
                    onClick={() => togglePreference(p)}
                    className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                      preferences.includes(p)
                        ? "bg-medical-500 text-white"
                        : "border border-slate-200 bg-white text-slate-600 hover:bg-medical-50"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <button type="submit" disabled={loading} className="btn-primary w-full gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              Generate Topics
            </button>
          </form>
        )}

        {stage === "results" && (
          <div className="mt-6">
            <div className="grid gap-4 sm:grid-cols-2">
              {topics.map((t, i) => (
                <div key={i} className="glass flex flex-col rounded-xl2 p-5">
                  <h3 className="font-display font-semibold text-slate-900">{t.title}</h3>
                  <dl className="mt-2 space-y-1.5 text-xs text-slate-600">
                    <div><dt className="inline font-semibold text-slate-700">Research Area: </dt><dd className="inline">{t.researchArea}</dd></div>
                    <div><dt className="inline font-semibold text-slate-700">Target Population: </dt><dd className="inline">{t.targetPopulation}</dd></div>
                    <div><dt className="inline font-semibold text-slate-700">Study Setting: </dt><dd className="inline">{t.studySetting}</dd></div>
                  </dl>
                  <p className="mt-2 text-sm text-slate-700">{t.briefExplanation}</p>
                  <p className="mt-2 text-xs italic text-slate-500">Feasibility: {t.feasibilityConsiderations}</p>

                  {refineOpenFor === i ? (
                    <div className="mt-3 space-y-2">
                      <textarea
                        autoFocus
                        value={refineText}
                        onChange={(e) => setRefineText(e.target.value)}
                        placeholder="e.g. Focus on rural facilities instead"
                        className="input-field"
                        rows={2}
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleRefine(i)}
                          disabled={refining === i}
                          className="btn-primary flex-1 py-1.5 text-xs"
                        >
                          {refining === i ? "Refining…" : "Apply refinement"}
                        </button>
                        <button
                          onClick={() => setRefineOpenFor(null)}
                          className="btn-secondary py-1.5 text-xs"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4 flex gap-2">
                      <button onClick={() => selectTopic(t)} className="btn-primary flex-1 py-1.5 text-xs">
                        SELECT
                      </button>
                      <button
                        onClick={() => {
                          setRefineOpenFor(i);
                          setRefineText("");
                        }}
                        className="btn-secondary py-1.5 text-xs"
                      >
                        REFINE
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <button onClick={() => handleGenerate()} disabled={loading} className="btn-secondary mt-5 gap-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
              GENERATE MORE
            </button>
          </div>
        )}

        {stage === "confirm" && chosen && (
          <div className="glass mt-6 max-w-lg rounded-xl2 p-6">
            <h2 className="font-display text-lg font-bold text-slate-900">Confirm your topic</h2>
            <h3 className="mt-3 font-semibold text-slate-900">{chosen.title}</h3>
            <dl className="mt-2 space-y-1.5 text-sm text-slate-600">
              <div><dt className="inline font-semibold text-slate-700">Research Area: </dt><dd className="inline">{chosen.researchArea}</dd></div>
              <div><dt className="inline font-semibold text-slate-700">Target Population: </dt><dd className="inline">{chosen.targetPopulation}</dd></div>
              <div><dt className="inline font-semibold text-slate-700">Study Setting: </dt><dd className="inline">{chosen.studySetting}</dd></div>
            </dl>
            <p className="mt-2 text-sm text-slate-700">{chosen.briefExplanation}</p>

            <div className="mt-4 space-y-2">
              <textarea
                value={refineText}
                onChange={(e) => setRefineText(e.target.value)}
                placeholder="Want a tweak before confirming? Describe it here (optional)"
                className="input-field"
                rows={2}
              />
              {refineText.trim() && (
                <button
                  onClick={() => handleRefine(topics.findIndex((t) => t.title === chosen.title))}
                  disabled={refining !== null}
                  className="btn-secondary w-full py-1.5 text-xs"
                >
                  {refining !== null ? "Refining…" : "Apply refinement"}
                </button>
              )}
            </div>

            <div className="mt-5 flex gap-2">
              <button onClick={() => setStage("results")} className="btn-secondary flex-1">
                ← Back to topics
              </button>
              <button onClick={confirmTopic} disabled={confirming} className="btn-primary flex-1">
                {confirming ? "Confirming…" : "Confirm Topic →"}
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
