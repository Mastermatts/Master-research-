import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import GenerateFlow from "./generate-flow";

export default async function GenerateTopicPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase.from("profiles").select("course").eq("id", user.id).single();

  return <GenerateFlow defaultProgramme={profile?.course ?? ""} />;
}
