"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  Download,
  Loader2,
  Sparkles,
  X,
} from "lucide-react";

type Category = "grammar" | "clarity" | "structure" | "citations" | "ai_hallucination" | "formatting";

type Correction = {
  id: string;
  category: Category;
  originalExcerpt: string;
  suggestedText: string;
  reason: string;
  status: "pending" | "accepted" | "rejected";
};

const CATEGORY_META: Record<Category, { label: string; warn?: boolean }> = {
  grammar: { label: "Grammar" },
  clarity: { label: "Clarity" },
  structure: { label: "Structure" },
  citations: { label: "Citations" },
  ai_hallucination: { label: "Possible AI hallucinations", warn: true },
  formatting: { label: "Formatting" },
};

type Stage = "analyzing" | "categories" | "review" | "final" | "done";

export default function DocumentReview({
  documentId,
  filename,
  initialStatus,
  initialCorrections,
}: {
  documentId: string;
  filename: string;
  initialStatus: string;
  initialCorrections: Correction[];
}) {
  const [stage, setStage] = useState<Stage>(initialStatus === "uploaded" ? "analyzing" : "categories");
  const [corrections, setCorrections] = useState<Correction[]>(initialCorrections);
  const [summary, setSummary] = useState<string>("");
  const [selectedCategories, setSelectedCategories] = useState<Category[]>(["ai_hallucination"]);
  const [error, setError] = useState<string | null>(null);
  const [finalizing, setFinalizing] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [applySummary, setApplySummary] = useState<{ applied: number; skipped: number } | null>(null);

  useEffect(() => {
    if (stage !== "analyzing") return;
    (async () => {
      try {
        const res = await fetch(`/api/research/documents/${documentId}/analyze`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({}),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Analysis failed");
        setCorrections(data.corrections);
        setSummary(data.summary);
        const found = Array.from(new Set(data.corrections.map((c: Correction) => c.category))) as Category[];
        setSelectedCategories(found);
        setStage("categories");
      } catch (err) {
        setError(err instanceof Error ? err.message : "Something went wrong");
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stage]);

  function toggleCategory(cat: Category) {
    setSelectedCategories((prev) => (prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]));
  }

  const categoriesPresent = Array.from(new Set(corrections.map((c) => c.category))) as Category[];
  const visibleCorrections = corrections.filter((c) => selectedCategories.includes(c.category));
  const hallucinations = visibleCorrections.filter((c) => c.category === "ai_hallucination");
  const otherCorrections = visibleCorrections.filter((c) => c.category !== "ai_hallucination");

  function setStatus(id: string, status: Correction["status"]) {
    setCorrections((prev) => prev.map((c) => (c.id === id ? { ...c, status } : c)));
  }

  const acceptedCount = visibleCorrections.filter((c) => c.status === "accepted").length;
  const rejectedCount = visibleCorrections.filter((c) => c.status === "rejected").length;
  const pendingCount = visibleCorrections.length - acceptedCount - rejectedCount;

  async function generateRevised() {
    setFinalizing(true);
    setError(null);
    try {
      const res = await fetch(`/api/research/documents/${documentId}/finalize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ corrections: visibleCorrections }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not generate the revised document");
      setDownloadUrl(data.downloadUrl);
      setApplySummary({ applied: data.appliedCount, skipped: data.skippedCount });
      setStage("done");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setFinalizing(false);
    }
  }

  return (
    <main className="min-h-screen bg-medical-50/40 px-6 py-10">
      <div className="mx-auto max-w-3xl">
        <Link href="/dashboard/research" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Research paths
        </Link>
        <h1 className="mt-1 font-display text-2xl font-bold text-slate-900">{filename}</h1>

        {error && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
        )}

        {stage === "analyzing" && (
          <div className="glass mt-6 flex flex-col items-center gap-3 rounded-xl2 p-10 text-center">
            <Loader2 className="h-8 w-8 animate-spin text-medical-500" />
            <p className="text-sm text-slate-600">Analyzing your document — grammar, clarity, structure, citations, and unverified claims…</p>
          </div>
        )}

        {stage === "categories" && (
          <div className="glass mt-6 rounded-xl2 p-6">
            {summary && <p className="mb-4 text-sm text-slate-700">{summary}</p>}
            <h2 className="font-display font-semibold text-slate-900">Select Correction Areas</h2>
            <p className="mb-3 text-sm text-slate-600">Choose which kinds of corrections to review.</p>
            <div className="flex flex-wrap gap-2">
              {categoriesPresent.map((cat) => {
                const meta = CATEGORY_META[cat];
                const count = corrections.filter((c) => c.category === cat).length;
                const selected = selectedCategories.includes(cat);
                return (
                  <button
                    key={cat}
                    onClick={() => toggleCategory(cat)}
                    className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium ${
                      selected
                        ? meta.warn
                          ? "bg-amber-500 text-white"
                          : "bg-medical-500 text-white"
                        : "border border-slate-200 bg-white text-slate-600 hover:bg-medical-50"
                    }`}
                  >
                    {meta.warn && <AlertTriangle className="h-3 w-3" />}
                    {meta.label} ({count})
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => setStage("review")}
              disabled={selectedCategories.length === 0}
              className="btn-primary mt-5"
            >
              Review Corrections →
            </button>
          </div>
        )}

        {stage === "review" && (
          <div className="mt-6 space-y-4">
            {hallucinations.length > 0 && (
              <div className="rounded-xl2 border-2 border-amber-300 bg-amber-50 p-5">
                <div className="mb-2 flex items-center gap-2 text-amber-800">
                  <AlertTriangle className="h-4 w-4" />
                  <h2 className="font-display font-semibold">Possible AI hallucinations</h2>
                </div>
                <p className="mb-3 text-xs text-amber-700">
                  These claims couldn't be verified from the document itself. Review each carefully.
                </p>
                <div className="space-y-2">
                  {hallucinations.map((c) => (
                    <CorrectionRow key={c.id} correction={c} onStatus={setStatus} />
                  ))}
                </div>
              </div>
            )}

            {otherCorrections.length > 0 && (
              <div className="glass rounded-xl2 p-5">
                <h2 className="mb-3 font-display font-semibold text-slate-900">Other corrections</h2>
                <div className="space-y-2">
                  {otherCorrections.map((c) => (
                    <CorrectionRow key={c.id} correction={c} onStatus={setStatus} />
                  ))}
                </div>
              </div>
            )}

            {visibleCorrections.length === 0 && (
              <div className="glass rounded-xl2 p-8 text-center text-sm text-slate-500">
                No corrections in the categories you selected.
              </div>
            )}

            <div className="flex gap-2">
              <button onClick={() => setStage("categories")} className="btn-secondary flex-1">
                ← Correction areas
              </button>
              <button onClick={() => setStage("final")} className="btn-primary flex-1">
                Final Review →
              </button>
            </div>
          </div>
        )}

        {stage === "final" && (
          <div className="glass mt-6 rounded-xl2 p-6">
            <h2 className="font-display font-semibold text-slate-900">Final Review</h2>
            <div className="mt-3 grid grid-cols-3 gap-3 text-center">
              <div className="rounded-lg bg-accent/10 py-3">
                <div className="font-display text-xl font-bold text-accent">{acceptedCount}</div>
                <div className="text-xs text-slate-500">Accepted</div>
              </div>
              <div className="rounded-lg bg-red-50 py-3">
                <div className="font-display text-xl font-bold text-red-500">{rejectedCount}</div>
                <div className="text-xs text-slate-500">Rejected</div>
              </div>
              <div className="rounded-lg bg-slate-100 py-3">
                <div className="font-display text-xl font-bold text-slate-500">{pendingCount}</div>
                <div className="text-xs text-slate-500">Not reviewed</div>
              </div>
            </div>
            {pendingCount > 0 && (
              <p className="mt-3 text-xs text-amber-600">
                {pendingCount} correction(s) haven&apos;t been accepted or rejected — they&apos;ll be left out of the revised document.
              </p>
            )}
            <div className="mt-5 flex gap-2">
              <button onClick={() => setStage("review")} className="btn-secondary flex-1">
                ← Back to review
              </button>
              <button onClick={generateRevised} disabled={finalizing} className="btn-primary flex-1 gap-2">
                {finalizing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                Generate Revised DOCX
              </button>
            </div>
          </div>
        )}

        {stage === "done" && (
          <div className="glass mt-6 flex flex-col items-center gap-3 rounded-xl2 p-10 text-center">
            <CheckCircle2 className="h-10 w-10 text-accent" />
            <p className="text-sm text-slate-700">
              Applied {applySummary?.applied} correction(s)
              {applySummary?.skipped ? ` (${applySummary.skipped} couldn't be matched exactly and were skipped)` : ""}.
            </p>
            {downloadUrl && (
              <a href={downloadUrl} className="btn-primary gap-2">
                <Download className="h-4 w-4" /> Download revised DOCX
              </a>
            )}
            <Link href="/dashboard/research" className="text-sm text-medical-600 hover:underline">
              Back to research paths
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}

function CorrectionRow({
  correction,
  onStatus,
}: {
  correction: Correction;
  onStatus: (id: string, status: Correction["status"]) => void;
}) {
  return (
    <div className="rounded-lg bg-white/80 p-3">
      <p className="text-xs text-slate-500 line-through">{correction.originalExcerpt}</p>
      <p className="text-sm font-medium text-slate-800">{correction.suggestedText}</p>
      <p className="mt-1 text-xs text-slate-500">{correction.reason}</p>
      <div className="mt-2 flex gap-2">
        <button
          onClick={() => onStatus(correction.id, "accepted")}
          className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium ${
            correction.status === "accepted" ? "bg-accent text-white" : "bg-slate-100 text-slate-600 hover:bg-accent/10"
          }`}
        >
          <Check className="h-3 w-3" /> Accept
        </button>
        <button
          onClick={() => onStatus(correction.id, "rejected")}
          className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium ${
            correction.status === "rejected" ? "bg-red-500 text-white" : "bg-slate-100 text-slate-600 hover:bg-red-50"
          }`}
        >
          <X className="h-3 w-3" /> Reject
        </button>
      </div>
    </div>
  );
}
