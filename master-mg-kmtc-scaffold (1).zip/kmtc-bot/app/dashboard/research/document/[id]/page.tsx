import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import DocumentReview from "./document-review";

export default async function DocumentReviewPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: doc } = await supabase
    .from("research_documents")
    .select("id, original_filename, status, corrections")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (!doc) notFound();

  return (
    <DocumentReview
      documentId={doc.id}
      filename={doc.original_filename}
      initialStatus={doc.status}
      initialCorrections={doc.corrections ?? []}
    />
  );
}
