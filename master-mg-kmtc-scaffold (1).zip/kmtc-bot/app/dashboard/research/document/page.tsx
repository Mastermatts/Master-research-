"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, FileUp, Loader2 } from "lucide-react";

export default function UploadDocumentPage() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;
    setUploading(true);
    setError(null);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/research/documents", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      router.push(`/dashboard/research/document/${data.documentId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
      setUploading(false);
    }
  }

  return (
    <main className="min-h-screen bg-medical-50/40 px-6 py-10">
      <div className="mx-auto max-w-lg">
        <Link href="/dashboard/research" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Research paths
        </Link>
        <h1 className="mt-1 font-display text-2xl font-bold text-slate-900">Upload your research document</h1>
        <p className="text-sm text-slate-600">DOCX or PDF. We'll check grammar, clarity, structure, citations, and flag anything that looks like an unverified AI-generated claim.</p>

        <form onSubmit={handleUpload} className="glass mt-6 rounded-xl2 p-6">
          <label className="flex flex-col items-center gap-2 rounded-xl border-2 border-dashed border-medical-200 p-8 text-center cursor-pointer hover:bg-medical-50">
            <FileUp className="h-8 w-8 text-medical-400" />
            <span className="text-sm font-medium text-slate-700">
              {file ? file.name : "Click to choose a .docx or .pdf file"}
            </span>
            <input
              type="file"
              accept=".docx,.pdf"
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </label>

          {error && <p className="mt-3 text-sm text-red-600">{error}</p>}

          <button type="submit" disabled={!file || uploading} className="btn-primary mt-5 w-full gap-2">
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileUp className="h-4 w-4" />}
            {uploading ? "Uploading…" : "Analyze Document"}
          </button>
        </form>
      </div>
    </main>
  );
}
