import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import ExistingFlow from "./existing-flow";

export default async function ExistingTopicPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  return <ExistingFlow />;
}
