"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { AlertTriangle, ArrowLeft, Check, Loader2 } from "lucide-react";

type Criterion = { comment: string; concern: boolean };
type Review = {
  grammar: Criterion;
  clarity: Criterion;
  specificity: Criterion;
  scope: Criterion;
  researchability: Criterion;
  targetPopulation: Criterion;
  variables: Criterion;
  studySetting: Criterion;
  feasibility: Criterion;
  overallSummary: string;
  suggestedRewrite: string | null;
};

const CRITERIA_LABELS: [keyof Review, string][] = [
  ["grammar", "Grammar"],
  ["clarity", "Clarity"],
  ["specificity", "Specificity"],
  ["scope", "Scope"],
  ["researchability", "Researchability"],
  ["targetPopulation", "Target Population"],
  ["variables", "Variables"],
  ["studySetting", "Study Setting"],
  ["feasibility", "Feasibility"],
];

export default function ExistingFlow() {
  const router = useRouter();
  const [topicText, setTopicText] = useState("");
  const [review, setReview] = useState<Review | null>(null);
  const [finalTopic, setFinalTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleReview(e: React.FormEvent) {
    e.preventDefault();
    if (!topicText.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/research/topics/review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topicText }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not review the topic");
      setReview(data.review);
      setFinalTopic(topicText);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  async function confirmTopic() {
    if (!finalTopic.trim()) return;
    setConfirming(true);
    setError(null);
    try {
      const res = await fetch("/api/research/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: "existing", topic: { title: finalTopic.trim() } }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not confirm topic");
      router.push(`/dashboard/research/builder/${data.projectId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
      setConfirming(false);
    }
  }

  return (
    <main className="min-h-screen bg-medical-50/40 px-6 py-10">
      <div className="mx-auto max-w-2xl">
        <Link href="/dashboard/research" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Research paths
        </Link>
        <h1 className="mt-1 font-display text-2xl font-bold text-slate-900">Review your research topic</h1>

        {error && (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
        )}

        {!review && (
          <form onSubmit={handleReview} className="glass mt-6 space-y-3 rounded-xl2 p-6">
            <label className="block text-sm font-semibold text-slate-800">Your topic</label>
            <textarea
              required
              autoFocus
              value={topicText}
              onChange={(e) => setTopicText(e.target.value)}
              placeholder="e.g. Assessment of healthcare workers' knowledge on proper use of medical equipment"
              className="input-field"
              rows={3}
            />
            <button type="submit" disabled={loading} className="btn-primary w-full gap-2">
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              Review Topic
            </button>
          </form>
        )}

        {review && (
          <div className="mt-6 space-y-4">
            <div className="glass rounded-xl2 p-5">
              <p className="text-sm text-slate-700">{review.overallSummary}</p>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {CRITERIA_LABELS.map(([key, label]) => {
                  const c = review[key] as Criterion;
                  return (
                    <div key={key} className="flex items-start gap-2 rounded-lg bg-white/70 p-2.5">
                      {c.concern ? (
                        <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-500" />
                      ) : (
                        <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" />
                      )}
                      <div>
                        <div className="text-xs font-semibold text-slate-800">{label}</div>
                        <div className="text-xs text-slate-600">{c.comment}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="glass rounded-xl2 p-5">
              <label className="mb-1 block text-sm font-semibold text-slate-800">Your original topic</label>
              <p className="mb-3 rounded-lg bg-white/70 p-3 text-sm text-slate-700">{topicText}</p>

              {review.suggestedRewrite && (
                <>
                  <label className="mb-1 block text-sm font-semibold text-slate-800">AI-suggested version</label>
                  <p className="mb-3 rounded-lg bg-medical-50 p-3 text-sm text-slate-700">{review.suggestedRewrite}</p>
                </>
              )}

              <label className="mb-1 block text-sm font-semibold text-slate-800">
                Final wording to use (edit freely — nothing is applied automatically)
              </label>
              <textarea
                value={finalTopic}
                onChange={(e) => setFinalTopic(e.target.value)}
                className="input-field"
                rows={3}
              />

              {review.suggestedRewrite && (
                <div className="mt-2 flex gap-2">
                  <button
                    onClick={() => setFinalTopic(topicText)}
                    className="btn-secondary flex-1 py-1.5 text-xs"
                  >
                    Use my original
                  </button>
                  <button
                    onClick={() => setFinalTopic(review.suggestedRewrite!)}
                    className="btn-secondary flex-1 py-1.5 text-xs"
                  >
                    Use suggested version
                  </button>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => {
                  setReview(null);
                }}
                className="btn-secondary flex-1"
              >
                ← Edit topic
              </button>
              <button onClick={confirmTopic} disabled={confirming || !finalTopic.trim()} className="btn-primary flex-1">
                {confirming ? "Confirming…" : "Confirm Topic →"}
              </button>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
