import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import TutorChat from "./tutor-chat";

export default async function TutorPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, subscription_tier")
    .eq("id", user.id)
    .single();

  return (
    <TutorChat
      userFirstName={profile?.full_name?.split(" ")[0] ?? null}
      subscriptionTier={(profile?.subscription_tier as "free" | "premium") ?? "free"}
    />
  );
}
