"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Lightbulb,
  ListChecks,
  Loader2,
  NotebookText,
  Plus,
  Send,
  Sparkles,
} from "lucide-react";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
};

type ConversationSummary = {
  id: string;
  title: string | null;
  created_at: string;
};

const QUICK_ACTIONS = [
  { icon: Lightbulb, label: "Explain a concept", prefill: "Explain " },
  { icon: Sparkles, label: "Create a mnemonic", prefill: "Create a mnemonic for " },
  { icon: NotebookText, label: "Summarize a topic", prefill: "Summarize " },
  { icon: ListChecks, label: "Revision notes", prefill: "Give me revision notes on " },
];

export default function TutorChat({
  userFirstName,
  subscriptionTier,
}: {
  userFirstName: string | null;
  subscriptionTier: "free" | "premium";
}) {
  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  async function loadConversations() {
    try {
      const res = await fetch("/api/ai/conversations");
      const data = await res.json();
      if (res.ok) setConversations(data.conversations ?? []);
    } catch {
      // Non-fatal — sidebar just stays empty.
    }
  }

  async function selectConversation(id: string) {
    setActiveId(id);
    setError(null);
    const res = await fetch(`/api/ai/conversations/${id}`);
    const data = await res.json();
    if (res.ok) {
      setMessages(
        (data.messages ?? []).map((m: { id: string; role: "user" | "assistant"; content: string }) => ({
          id: m.id,
          role: m.role,
          content: m.content,
        }))
      );
    }
  }

  function startNewChat() {
    setActiveId(null);
    setMessages([]);
    setError(null);
  }

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || streaming) return;

    setError(null);
    setInput("");

    const userMessage: Message = { id: crypto.randomUUID(), role: "user", content: trimmed };
    const assistantMessage: Message = { id: crypto.randomUUID(), role: "assistant", content: "" };
    setMessages((prev) => [...prev, userMessage, assistantMessage]);
    setStreaming(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId: activeId, message: trimmed }),
      });

      if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "The AI Tutor couldn't respond. Please try again.");
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let newConversationId: string | null = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const events = buffer.split("\n\n");
        buffer = events.pop() ?? "";

        for (const evt of events) {
          const line = evt.trim();
          if (!line.startsWith("data:")) continue;
          const payload = JSON.parse(line.slice(5).trim());

          if (payload.type === "meta") {
            newConversationId = payload.conversationId;
          } else if (payload.type === "token") {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMessage.id ? { ...m, content: m.content + payload.text } : m
              )
            );
          } else if (payload.type === "error") {
            setError(payload.message);
          }
        }
      }

      if (newConversationId && newConversationId !== activeId) {
        setActiveId(newConversationId);
        loadConversations();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setMessages((prev) => prev.filter((m) => m.id !== assistantMessage.id));
    } finally {
      setStreaming(false);
    }
  }

  return (
    <main className="flex min-h-screen bg-medical-50/40">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-medical-100 bg-white/70 p-4 md:flex">
        <Link href="/dashboard" className="mb-4 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
          <ArrowLeft className="h-4 w-4" /> Dashboard
        </Link>
        <button onClick={startNewChat} className="btn-primary mb-4 w-full gap-2">
          <Plus className="h-4 w-4" /> New chat
        </button>
        <div className="flex-1 space-y-1 overflow-y-auto">
          {conversations.length === 0 && (
            <p className="px-2 text-xs text-slate-400">Your conversations will show up here.</p>
          )}
          {conversations.map((c) => (
            <button
              key={c.id}
              onClick={() => selectConversation(c.id)}
              className={`block w-full truncate rounded-lg px-3 py-2 text-left text-sm ${
                c.id === activeId ? "bg-medical-100 text-medical-800" : "text-slate-600 hover:bg-medical-50"
              }`}
            >
              {c.title || "New conversation"}
            </button>
          ))}
        </div>
        {subscriptionTier === "free" && (
          <div className="mt-4 rounded-xl bg-medical-500/10 p-3 text-xs text-medical-700">
            Free plan: 30 questions/day. Upgrade for unlimited AI tutoring.
          </div>
        )}
      </aside>

      {/* Chat column */}
      <div className="flex min-h-screen flex-1 flex-col">
        <header className="border-b border-medical-100 bg-white/70 px-6 py-4">
          <h1 className="font-display text-lg font-bold text-slate-900">AI Medical Tutor</h1>
          <p className="text-xs text-slate-500">
            {userFirstName ? `Hi ${userFirstName} — ` : ""}ask anything, from Boyle&apos;s Law to
            clinical case reasoning.
          </p>
        </header>

        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-6 sm:px-8">
          {messages.length === 0 ? (
            <EmptyState onQuickAction={(prefill) => setInput(prefill)} />
          ) : (
            <div className="mx-auto max-w-2xl space-y-4">
              {messages.map((m) => (
                <ChatBubble key={m.id} message={m} streaming={streaming && m.role === "assistant" && m === messages[messages.length - 1]} />
              ))}
              {error && (
                <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                  {error}
                </div>
              )}
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage(input);
          }}
          className="border-t border-medical-100 bg-white/80 px-4 py-4 sm:px-8"
        >
          <div className="mx-auto flex max-w-2xl items-end gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage(input);
                }
              }}
              rows={1}
              placeholder="Ask about a topic, e.g. Difference between sterilization and disinfection..."
              className="input-field max-h-32 flex-1 resize-none"
            />
            <button type="submit" disabled={streaming || !input.trim()} className="btn-primary h-[42px] shrink-0 px-4">
              {streaming ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </div>
        </form>
      </div>
    </main>
  );
}

function EmptyState({ onQuickAction }: { onQuickAction: (prefill: string) => void }) {
  return (
    <div className="mx-auto flex max-w-2xl flex-col items-center pt-10 text-center">
      <div className="glass mb-6 flex h-14 w-14 items-center justify-center rounded-full">
        <Sparkles className="h-6 w-6 text-medical-500" />
      </div>
      <h2 className="font-display text-xl font-bold text-slate-900">What are you studying today?</h2>
      <p className="mt-1 max-w-sm text-sm text-slate-600">
        Ask a question in your own words, or start from a quick action below.
      </p>
      <div className="mt-6 grid w-full grid-cols-1 gap-3 sm:grid-cols-2">
        {QUICK_ACTIONS.map(({ icon: Icon, label, prefill }) => (
          <button
            key={label}
            onClick={() => onQuickAction(prefill)}
            className="glass flex items-center gap-3 rounded-xl2 p-4 text-left transition-transform hover:-translate-y-0.5"
          >
            <Icon className="h-5 w-5 shrink-0 text-medical-500" />
            <span className="text-sm font-medium text-slate-800">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function ChatBubble({ message, streaming }: { message: Message; streaming: boolean }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser ? "bg-medical-500 text-white" : "glass text-slate-800"
        }`}
      >
        {message.content || (streaming ? <TypingDots /> : "")}
        {streaming && message.content && <span className="ml-0.5 inline-block h-4 w-1 animate-pulse bg-medical-400 align-middle" />}
      </div>
    </div>
  );
}

function TypingDots() {
  return (
    <span className="inline-flex gap-1">
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-medical-400 [animation-delay:-0.3s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-medical-400 [animation-delay:-0.15s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-medical-400" />
    </span>
  );
}
