import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getUserRole } from "@/lib/auth/roles";
import LibraryBrowser from "./library-browser";

export default async function LibraryPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const role = await getUserRole(supabase, user.id);

  const { data: subjects } = await supabase
    .from("subjects")
    .select("id, name, department")
    .order("department", { ascending: true })
    .order("name", { ascending: true });

  return <LibraryBrowser subjects={subjects ?? []} canUpload={role === "admin" || role === "lecturer"} />;
}
