"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Bookmark,
  BookmarkCheck,
  BookOpen,
  ClipboardList,
  Download,
  FileText,
  GraduationCap,
  Loader2,
  NotebookText,
  Presentation,
  Search,
  Sparkles,
  Upload,
  X,
} from "lucide-react";

type Subject = { id: string; name: string; department: string };

type Resource = {
  id: string;
  title: string;
  description: string | null;
  type: string;
  year: number | null;
  file_size_kb: number | null;
  is_premium: boolean;
  downloads_count: number;
  created_at: string;
  subjects: { id: string; name: string; department: string } | null;
  isBookmarked: boolean;
};

const TYPE_META: Record<string, { label: string; icon: typeof FileText }> = {
  notes: { label: "Notes", icon: NotebookText },
  book: { label: "Book", icon: BookOpen },
  slides: { label: "Slides", icon: Presentation },
  manual: { label: "Manual", icon: ClipboardList },
  revision: { label: "Revision", icon: GraduationCap },
  past_paper: { label: "Past Paper", icon: FileText },
};

const TYPE_FILTERS = [
  { value: "", label: "All" },
  ...Object.entries(TYPE_META).map(([value, m]) => ({ value, label: m.label })),
];

export default function LibraryBrowser({
  subjects,
  canUpload,
}: {
  subjects: Subject[];
  canUpload: boolean;
}) {
  const [subjectId, setSubjectId] = useState("");
  const [type, setType] = useState("");
  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [resources, setResources] = useState<Resource[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q), 350);
    return () => clearTimeout(t);
  }, [q]);

  const fetchResources = useCallback(
    async (targetPage: number) => {
      setLoading(true);
      setError(null);
      const params = new URLSearchParams();
      if (subjectId) params.set("subjectId", subjectId);
      if (type) params.set("type", type);
      if (debouncedQ) params.set("q", debouncedQ);
      params.set("page", String(targetPage));

      try {
        const res = await fetch(`/api/library/resources?${params.toString()}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Could not load resources");

        setResources((prev) => (targetPage === 1 ? data.resources : [...prev, ...data.resources]));
        setTotal(data.total);
        setPage(targetPage);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Something went wrong");
      } finally {
        setLoading(false);
      }
    },
    [subjectId, type, debouncedQ]
  );

  useEffect(() => {
    fetchResources(1);
  }, [fetchResources]);

  async function toggleBookmark(resourceId: string) {
    setResources((prev) =>
      prev.map((r) => (r.id === resourceId ? { ...r, isBookmarked: !r.isBookmarked } : r))
    );
    try {
      const res = await fetch("/api/library/bookmarks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resourceId }),
      });
      if (!res.ok) throw new Error();
    } catch {
      // Revert on failure.
      setResources((prev) =>
        prev.map((r) => (r.id === resourceId ? { ...r, isBookmarked: !r.isBookmarked } : r))
      );
    }
  }

  const hasMore = resources.length < total;

  return (
    <main className="min-h-screen bg-medical-50/40">
      <header className="border-b border-medical-100 bg-white/70 px-6 py-4">
        <div className="mx-auto flex max-w-6xl items-center justify-between">
          <div>
            <Link href="/dashboard" className="mb-1 inline-flex items-center gap-1 text-sm text-medical-600 hover:underline">
              <ArrowLeft className="h-4 w-4" /> Dashboard
            </Link>
            <h1 className="font-display text-xl font-bold text-slate-900">Digital Library</h1>
          </div>
          {canUpload && (
            <button onClick={() => setUploadOpen(true)} className="btn-primary gap-2">
              <Upload className="h-4 w-4" /> Upload resource
            </button>
          )}
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-6 py-8">
        {/* Search + subject + type filters */}
        <div className="glass rounded-xl2 p-4">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search notes, books, past papers..."
              className="input-field pl-9"
            />
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            <select value={subjectId} onChange={(e) => setSubjectId(e.target.value)} className="input-field w-auto">
              <option value="">All subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} — {s.department}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {TYPE_FILTERS.map((f) => (
              <button
                key={f.value}
                onClick={() => setType(f.value)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                  type === f.value
                    ? "bg-medical-500 text-white"
                    : "bg-white text-slate-600 hover:bg-medical-50 border border-slate-200"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        <div className="mt-6">
          {error && (
            <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          )}

          {!loading && resources.length === 0 && !error && (
            <div className="glass rounded-xl2 p-10 text-center text-sm text-slate-500">
              No resources match your filters yet.
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {resources.map((r) => (
              <ResourceCard key={r.id} resource={r} onToggleBookmark={() => toggleBookmark(r.id)} />
            ))}
          </div>

          {loading && (
            <div className="mt-6 flex justify-center">
              <Loader2 className="h-5 w-5 animate-spin text-medical-500" />
            </div>
          )}

          {!loading && hasMore && (
            <div className="mt-6 flex justify-center">
              <button onClick={() => fetchResources(page + 1)} className="btn-secondary">
                Load more
              </button>
            </div>
          )}
        </div>
      </div>

      {uploadOpen && (
        <UploadModal
          subjects={subjects}
          onClose={() => setUploadOpen(false)}
          onUploaded={() => {
            setUploadOpen(false);
            fetchResources(1);
          }}
        />
      )}
    </main>
  );
}

function ResourceCard({ resource, onToggleBookmark }: { resource: Resource; onToggleBookmark: () => void }) {
  const meta = TYPE_META[resource.type] ?? TYPE_META.notes;
  const Icon = meta.icon;

  return (
    <div className="glass flex flex-col rounded-xl2 p-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <div className="rounded-lg bg-medical-500/10 p-2">
            <Icon className="h-4 w-4 text-medical-600" />
          </div>
          <span className="rounded-full bg-medical-50 px-2 py-0.5 text-[11px] font-semibold text-medical-700">
            {meta.label}
          </span>
          {resource.is_premium && (
            <span className="inline-flex items-center gap-1 rounded-full bg-accent/10 px-2 py-0.5 text-[11px] font-semibold text-accent">
              <Sparkles className="h-3 w-3" /> Premium
            </span>
          )}
        </div>
        <button onClick={onToggleBookmark} aria-label="Toggle bookmark" className="text-medical-500 hover:text-medical-700">
          {resource.isBookmarked ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
        </button>
      </div>

      <h3 className="mt-3 font-display text-sm font-semibold text-slate-900">{resource.title}</h3>
      {resource.description && (
        <p className="mt-1 line-clamp-2 text-xs text-slate-600">{resource.description}</p>
      )}

      <div className="mt-3 text-xs text-slate-500">
        {resource.subjects?.name}
        {resource.year ? ` · ${resource.year}` : ""}
      </div>

      <div className="mt-4 flex items-center justify-between">
        <span className="text-[11px] text-slate-400">{resource.downloads_count} downloads</span>
        <a href={`/api/library/resources/${resource.id}/download`} className="btn-secondary gap-1 px-3 py-1.5 text-xs">
          <Download className="h-3.5 w-3.5" /> Download
        </a>
      </div>
    </div>
  );
}

function UploadModal({
  subjects,
  onClose,
  onUploaded,
}: {
  subjects: Subject[];
  onClose: () => void;
  onUploaded: () => void;
}) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [subjectId, setSubjectId] = useState(subjects[0]?.id ?? "");
  const [type, setType] = useState("notes");
  const [year, setYear] = useState("");
  const [isPremium, setIsPremium] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) {
      setError("Choose a file to upload");
      return;
    }
    setSubmitting(true);
    setError(null);

    const formData = new FormData();
    formData.append("file", file);
    formData.append("title", title);
    formData.append("description", description);
    formData.append("subjectId", subjectId);
    formData.append("type", type);
    if (year) formData.append("year", year);
    formData.append("isPremium", String(isPremium));

    try {
      const res = await fetch("/api/library/resources", { method: "POST", body: formData });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      onUploaded();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 px-4">
      <div className="glass w-full max-w-md rounded-xl2 bg-white p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-slate-900">Upload resource</h2>
          <button onClick={onClose} aria-label="Close">
            <X className="h-5 w-5 text-slate-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            required
            placeholder="Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="input-field"
          />
          <textarea
            placeholder="Description (optional)"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="input-field"
            rows={2}
          />
          <div className="grid grid-cols-2 gap-3">
            <select value={subjectId} onChange={(e) => setSubjectId(e.target.value)} className="input-field">
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            <select value={type} onChange={(e) => setType(e.target.value)} className="input-field">
              {Object.entries(TYPE_META).map(([value, m]) => (
                <option key={value} value={value}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input
              type="number"
              placeholder="Year (optional)"
              value={year}
              onChange={(e) => setYear(e.target.value)}
              className="input-field"
            />
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input type="checkbox" checked={isPremium} onChange={(e) => setIsPremium(e.target.checked)} />
              Premium only
            </label>
          </div>
          <input
            required
            type="file"
            accept=".pdf,.doc,.docx,.ppt,.pptx"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="input-field"
          />
          <p className="text-[11px] text-slate-400">
            PDFs are automatically indexed so the AI Tutor can reference them. Max 30MB.
          </p>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button type="submit" disabled={submitting} className="btn-primary w-full">
            {submitting ? "Uploading…" : "Upload"}
          </button>
        </form>
      </div>
    </div>
  );
}
