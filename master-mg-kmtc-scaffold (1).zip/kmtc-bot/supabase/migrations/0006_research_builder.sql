-- ============================================================================
-- RESEARCH PROJECT WORKFLOW — Paths A/B (topic → confirmed project → guided
-- builder) and Path C (upload an existing document for AI-assisted review).
-- ============================================================================

create type research_path as enum ('generate', 'existing', 'upload');
create type research_project_status as enum ('draft', 'topic_confirmed', 'building', 'complete');
create type research_document_status as enum ('uploaded', 'analyzing', 'analyzed', 'finalized');

-- ---------------------------------------------------------------------------
-- Paths A & B: the confirmed research topic + project
-- ---------------------------------------------------------------------------
create table public.research_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  path research_path not null,
  programme text,
  research_area text,
  preferences text[],
  topic_title text,
  target_population text,
  study_setting text,
  brief_explanation text,
  feasibility_notes text,
  status research_project_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index research_projects_user_idx on public.research_projects (user_id, created_at desc);

-- The guided, one-at-a-time Research Document Builder. Rows are seeded from
-- the fixed preliminary-pages list (lib/research/preliminary-pages.ts) when
-- a topic is confirmed.
create table public.research_project_pages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.research_projects(id) on delete cascade,
  page_key text not null,
  title text not null,
  content text not null default '',
  is_complete boolean not null default false,
  sort_order integer not null default 0,
  updated_at timestamptz not null default now(),
  unique (project_id, page_key)
);

-- ---------------------------------------------------------------------------
-- Path C: upload an existing document for AI-assisted correction
-- ---------------------------------------------------------------------------
create table public.research_documents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  original_filename text not null,
  storage_path text not null,
  file_type text,
  extracted_text text,
  -- Each item: { id, category, originalExcerpt, suggestedText, reason, status }
  -- status is one of 'pending' | 'accepted' | 'rejected', set client-side as
  -- the student works through Review Corrections / Accept-Reject.
  corrections jsonb not null default '[]'::jsonb,
  selected_categories text[] not null default '{}',
  status research_document_status not null default 'uploaded',
  revised_storage_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index research_documents_user_idx on public.research_documents (user_id, created_at desc);

-- ---------------------------------------------------------------------------
-- RLS — owner-only across the board
-- ---------------------------------------------------------------------------
alter table public.research_projects enable row level security;
alter table public.research_project_pages enable row level security;
alter table public.research_documents enable row level security;

create policy "research projects owner rw" on public.research_projects
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "research project pages owner rw" on public.research_project_pages
  for all using (
    exists (select 1 from public.research_projects p where p.id = project_id and p.user_id = auth.uid())
  ) with check (
    exists (select 1 from public.research_projects p where p.id = project_id and p.user_id = auth.uid())
  );

create policy "research documents owner rw" on public.research_documents
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create trigger set_research_project_updated_at
  before update on public.research_projects
  for each row execute procedure public.set_updated_at();

create trigger set_research_document_updated_at
  before update on public.research_documents
  for each row execute procedure public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Private storage bucket for Path C uploads + generated revised documents
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('research-documents', 'research-documents', false)
on conflict (id) do nothing;

create policy "research documents bucket owner rw"
  on storage.objects for all
  using (bucket_id = 'research-documents' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'research-documents' and (storage.foldername(name))[1] = auth.uid()::text);
