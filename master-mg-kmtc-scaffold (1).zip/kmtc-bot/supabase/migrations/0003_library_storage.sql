-- ============================================================================
-- DIGITAL LIBRARY — Supabase Storage bucket + policies
-- ============================================================================

-- Private bucket: files are only reachable via short-lived signed URLs
-- (see /api/library/resources/[id]/download), which also lets us gate
-- premium-only resources and count downloads.
insert into storage.buckets (id, name, public)
values ('resources', 'resources', false)
on conflict (id) do nothing;

create policy "resources bucket readable by authenticated"
  on storage.objects for select
  using (bucket_id = 'resources' and auth.role() = 'authenticated');

create policy "resources bucket writable by staff"
  on storage.objects for insert
  with check (
    bucket_id = 'resources'
    and (
      public.is_admin()
      or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
    )
  );

create policy "resources bucket updatable by staff"
  on storage.objects for update
  using (
    bucket_id = 'resources'
    and (
      public.is_admin()
      or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
    )
  );

create policy "resources bucket deletable by staff"
  on storage.objects for delete
  using (
    bucket_id = 'resources'
    and (
      public.is_admin()
      or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
    )
  );

-- Lets any authenticated reader bump downloads_count without needing a
-- direct UPDATE grant on public.resources.
create function public.increment_resource_downloads(resource_id uuid)
returns void
language sql
security definer set search_path = public
as $$
  update public.resources
  set downloads_count = downloads_count + 1
  where id = resource_id;
$$;
