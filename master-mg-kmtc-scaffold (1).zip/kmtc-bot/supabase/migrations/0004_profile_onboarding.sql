-- ============================================================================
-- PROGRESSIVE PROFILE ONBOARDING
-- ============================================================================

alter table public.profiles
  add column if not exists course text,
  add column if not exists onboarding_step smallint not null default 0,
  add column if not exists onboarding_completed boolean not null default false;

-- Anyone who already has a name on file (e.g. signed up before this wizard
-- existed) shouldn't get funneled into onboarding on their next login.
update public.profiles
set onboarding_completed = true
where full_name is not null and onboarding_completed = false;
