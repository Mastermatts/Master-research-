-- ============================================================================
-- RESEARCH PROFILE FIELDS — admin-configurable steps 5–13 of the onboarding
-- wizard (Campus, Academic Year, Submission Month, Submission Date, Research
-- Topic, Research Area, Supervisor Name, Supervisor Department, Institutional
-- Information). Steps 1–4 (Full Name, Admission Number, Course, Department)
-- stay as real columns on `profiles` — see 0004 — because other features
-- (Library uploads, dashboard, RLS) already depend on those existing.
-- ============================================================================

create type field_type as enum ('text', 'textarea', 'select', 'date');

-- Admin-managed field definitions. "Removing" a field is a soft delete
-- (is_active = false) so a student's previously-collected answer for it
-- isn't orphaned or silently destroyed if it's added back later.
create table public.research_profile_fields (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,              -- stable slug, e.g. 'research_topic'
  label text not null,
  field_type field_type not null default 'text',
  options jsonb,                         -- for field_type = 'select': ["Option A", "Option B"]
  placeholder text,
  helper_text text,
  is_required boolean not null default true,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index research_profile_fields_active_order_idx
  on public.research_profile_fields (is_active, sort_order);

-- One row per (student, field). Kept separate from `profiles` specifically
-- so an admin can add/remove fields without a schema migration each time.
create table public.student_research_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  field_id uuid not null references public.research_profile_fields(id) on delete cascade,
  value text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, field_id)
);

alter table public.research_profile_fields enable row level security;
alter table public.student_research_profiles enable row level security;

create policy "research fields readable by authenticated" on public.research_profile_fields
  for select using (auth.role() = 'authenticated');

create policy "research fields writable by admin" on public.research_profile_fields
  for all using (public.is_admin()) with check (public.is_admin());

create policy "student research answers owner rw" on public.student_research_profiles
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "student research answers readable by admin" on public.student_research_profiles
  for select using (public.is_admin());

-- Small reusable trigger fn to keep `updated_at` current.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger set_research_field_updated_at
  before update on public.research_profile_fields
  for each row execute procedure public.set_updated_at();

create trigger set_student_research_profile_updated_at
  before update on public.student_research_profiles
  for each row execute procedure public.set_updated_at();

-- ---------------------------------------------------------------------------
-- Seed: the default research profile template (steps 5–13 from the spec).
-- Submission Date and Institutional Information are marked optional
-- ("where required" in the spec). Admins can edit/deactivate/reorder any of
-- these, or add new ones, from /admin/research-fields.
-- ---------------------------------------------------------------------------
insert into public.research_profile_fields
  (key, label, field_type, options, placeholder, helper_text, is_required, sort_order)
values
  ('campus', 'Campus', 'text', null, 'e.g. Nairobi', null, true, 10),
  ('academic_year', 'Academic Year', 'text', null, 'e.g. 2024', null, true, 20),
  ('submission_month', 'Submission Month', 'select',
    '["January","February","March","April","May","June","July","August","September","October","November","December"]',
    'Select submission month', null, true, 30),
  ('submission_date', 'Submission Date', 'date', null, null, 'Only if your programme requires an exact date.', false, 40),
  ('research_topic', 'Research Topic', 'textarea', null,
    'e.g. Assessment of Healthcare Workers'' Knowledge on the Proper Use of Medical Equipment', null, true, 50),
  ('research_area', 'Research Area', 'text', null, 'e.g. Medical Equipment Management', null, true, 60),
  ('supervisor_name', 'Lecturer / Supervisor Name', 'text', null, 'e.g. Example Lecturer', null, true, 70),
  ('supervisor_department', 'Lecturer / Supervisor Department', 'text', null, 'e.g. Medical Engineering', null, true, 80),
  ('institutional_info', 'Institutional Information', 'textarea', null,
    'e.g. affiliated hospital or institution, where applicable', 'Only if your research is affiliated with an external institution.', false, 90)
on conflict (key) do nothing;
