-- ============================================================================
-- AI TUTOR — retrieval-augmented generation support
-- ============================================================================

create extension if not exists "vector";

-- Chunked, embedded text pulled from library resources (notes, books, past
-- papers). Populated by an ingestion step (Smart PDF Reader phase) — the
-- tutor works fine with this table empty, it just answers from general
-- medical knowledge instead of citing your library.
create table public.resource_chunks (
  id uuid primary key default gen_random_uuid(),
  resource_id uuid not null references public.resources(id) on delete cascade,
  chunk_index integer not null default 0,
  content text not null,
  embedding vector(1536), -- text-embedding-3-small dimensions
  created_at timestamptz not null default now()
);

create index resource_chunks_embedding_idx on public.resource_chunks
  using ivfflat (embedding vector_cosine_ops) with (lists = 100);

create index resource_chunks_resource_idx on public.resource_chunks (resource_id);

alter table public.resource_chunks enable row level security;

create policy "resource chunks readable by authenticated" on public.resource_chunks
  for select using (auth.role() = 'authenticated');

create policy "resource chunks writable by staff" on public.resource_chunks
  for all using (
    public.is_admin()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
  );

-- Cosine-similarity search over chunks, joined back to their resource/subject
-- so the tutor can cite "From <resource_title> (<subject_name>)".
create function public.match_resource_chunks(
  query_embedding vector(1536),
  match_count int default 5,
  match_threshold float default 0.72
)
returns table (
  chunk_id uuid,
  resource_id uuid,
  resource_title text,
  subject_name text,
  content text,
  similarity float
)
language sql stable
as $$
  select
    rc.id as chunk_id,
    rc.resource_id,
    r.title as resource_title,
    s.name as subject_name,
    rc.content,
    1 - (rc.embedding <=> query_embedding) as similarity
  from public.resource_chunks rc
  join public.resources r on r.id = rc.resource_id
  join public.subjects s on s.id = r.subject_id
  where rc.embedding is not null
    and 1 - (rc.embedding <=> query_embedding) > match_threshold
  order by rc.embedding <=> query_embedding
  limit match_count;
$$;
