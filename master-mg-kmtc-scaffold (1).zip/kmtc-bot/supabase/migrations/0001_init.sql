-- ============================================================================
-- MASTER MG KMTC AI LEARNING BOT — initial schema
-- Run this in the Supabase SQL editor, or via `supabase db push`.
-- ============================================================================

-- ---------- Extensions ----------
create extension if not exists "pgcrypto";
create extension if not exists "pg_trgm"; -- fuzzy/semantic-ish text search

-- ---------- Enums ----------
create type user_role as enum ('student', 'lecturer', 'admin');
create type subscription_tier as enum ('free', 'premium');
create type resource_type as enum ('notes', 'book', 'slides', 'manual', 'revision', 'past_paper');
create type quiz_type as enum ('mcq', 'true_false', 'fill_blank', 'case_study', 'practical');
create type notification_type as enum ('exam', 'assignment', 'new_resource', 'ai_tip', 'system');

-- ============================================================================
-- PROFILES  (1:1 with auth.users)
-- ============================================================================
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text unique,
  admission_number text unique,
  department text,
  role user_role not null default 'student',
  avatar_url text,
  telegram_chat_id bigint unique,
  subscription_tier subscription_tier not null default 'free',
  streak_count integer not null default 0,
  last_active_date date,
  daily_content_hour smallint default 7 check (daily_content_hour between 0 and 23),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Auto-create a profile row whenever a new auth user signs up
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================================
-- SUBJECTS  (Anatomy, Physiology, Pharmacology, ...)
-- ============================================================================
create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  department text not null,
  description text,
  icon text,
  created_at timestamptz not null default now(),
  unique (name, department)
);

-- ============================================================================
-- RESOURCES  (notes, books, slides, manuals, past papers)
-- ============================================================================
create table public.resources (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  type resource_type not null,
  title text not null,
  description text,
  file_url text not null,
  file_size_kb integer,
  year integer,
  uploaded_by uuid references public.profiles(id) on delete set null,
  is_premium boolean not null default false,
  downloads_count integer not null default 0,
  search_vector tsvector generated always as (
    to_tsvector('english', coalesce(title, '') || ' ' || coalesce(description, ''))
  ) stored,
  created_at timestamptz not null default now()
);

create index resources_search_idx on public.resources using gin (search_vector);
create index resources_subject_idx on public.resources (subject_id);
create index resources_type_idx on public.resources (type);

create table public.bookmarks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  resource_id uuid not null references public.resources(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, resource_id)
);

-- ============================================================================
-- QUIZZES
-- ============================================================================
create table public.quizzes (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid references public.subjects(id) on delete set null,
  source_resource_id uuid references public.resources(id) on delete set null,
  title text not null,
  type quiz_type not null default 'mcq',
  created_by uuid references public.profiles(id) on delete set null,
  is_ai_generated boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  question text not null,
  options jsonb,               -- e.g. ["A) ...", "B) ...", "C) ...", "D) ..."]
  correct_answer text not null,
  explanation text,
  position integer not null default 0
);

create table public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  answers jsonb not null default '{}'::jsonb,
  score numeric(5,2),
  total_questions integer,
  started_at timestamptz not null default now(),
  completed_at timestamptz
);

-- ============================================================================
-- FLASHCARDS
-- ============================================================================
create table public.flashcards (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid references public.subjects(id) on delete cascade,
  source_resource_id uuid references public.resources(id) on delete set null,
  question text not null,
  answer text not null,
  created_by uuid references public.profiles(id) on delete set null,
  is_ai_generated boolean not null default true,
  created_at timestamptz not null default now()
);

-- ============================================================================
-- STUDY PLANNER
-- ============================================================================
create table public.study_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  schedule jsonb not null default '[]'::jsonb, -- [{subject, day, start, end, done}]
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================================
-- NOTIFICATIONS
-- ============================================================================
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type notification_type not null default 'system',
  title text not null,
  message text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

-- ============================================================================
-- AI TUTOR CHAT HISTORY (for RAG context + dashboard history)
-- ============================================================================
create table public.ai_conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text,
  created_at timestamptz not null default now()
);

create table public.ai_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.ai_conversations(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamptz not null default now()
);

-- ============================================================================
-- SUBSCRIPTIONS (premium tier)
-- ============================================================================
create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  tier subscription_tier not null default 'premium',
  status text not null default 'active' check (status in ('active', 'cancelled', 'expired')),
  started_at timestamptz not null default now(),
  expires_at timestamptz
);

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================
alter table public.profiles enable row level security;
alter table public.subjects enable row level security;
alter table public.resources enable row level security;
alter table public.bookmarks enable row level security;
alter table public.quizzes enable row level security;
alter table public.quiz_questions enable row level security;
alter table public.quiz_attempts enable row level security;
alter table public.flashcards enable row level security;
alter table public.study_plans enable row level security;
alter table public.notifications enable row level security;
alter table public.ai_conversations enable row level security;
alter table public.ai_messages enable row level security;
alter table public.subscriptions enable row level security;

-- Helper: is the current user an admin?
create function public.is_admin()
returns boolean
language sql security definer set search_path = public
as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$;

-- ---- profiles ----
create policy "profiles are viewable by owner" on public.profiles
  for select using (auth.uid() = id or public.is_admin());
create policy "profiles are updatable by owner" on public.profiles
  for update using (auth.uid() = id or public.is_admin());
create policy "admins can insert profiles" on public.profiles
  for insert with check (public.is_admin() or auth.uid() = id);

-- ---- subjects (public read, admin write) ----
create policy "subjects readable by all authenticated" on public.subjects
  for select using (auth.role() = 'authenticated');
create policy "subjects writable by admin" on public.subjects
  for all using (public.is_admin()) with check (public.is_admin());

-- ---- resources (readable by authenticated unless premium-gated) ----
create policy "resources readable by authenticated" on public.resources
  for select using (
    auth.role() = 'authenticated'
    and (
      not is_premium
      or public.is_admin()
      or exists (
        select 1 from public.profiles p
        where p.id = auth.uid() and p.subscription_tier = 'premium'
      )
    )
  );
create policy "resources writable by admin or lecturer" on public.resources
  for all using (
    public.is_admin()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
  ) with check (
    public.is_admin()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
  );

-- ---- bookmarks (owner only) ----
create policy "bookmarks owner rw" on public.bookmarks
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---- quizzes / questions (read for all authenticated, write for admin/lecturer/AI service) ----
create policy "quizzes readable" on public.quizzes
  for select using (auth.role() = 'authenticated');
create policy "quizzes writable by owner or staff" on public.quizzes
  for all using (
    auth.uid() = created_by or public.is_admin()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
  );
create policy "quiz questions readable" on public.quiz_questions
  for select using (auth.role() = 'authenticated');
create policy "quiz questions writable by staff" on public.quiz_questions
  for all using (
    public.is_admin()
    or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'lecturer')
  );

-- ---- quiz attempts (owner only) ----
create policy "quiz attempts owner rw" on public.quiz_attempts
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---- flashcards (read all, write owner/staff) ----
create policy "flashcards readable" on public.flashcards
  for select using (auth.role() = 'authenticated');
create policy "flashcards writable by owner or staff" on public.flashcards
  for all using (auth.uid() = created_by or public.is_admin());

-- ---- study plans (owner only) ----
create policy "study plans owner rw" on public.study_plans
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---- notifications (owner read, admin write) ----
create policy "notifications owner read" on public.notifications
  for select using (auth.uid() = user_id);
create policy "notifications owner update" on public.notifications
  for update using (auth.uid() = user_id);
create policy "notifications admin insert" on public.notifications
  for insert with check (public.is_admin() or auth.uid() = user_id);

-- ---- AI chat (owner only) ----
create policy "ai conversations owner rw" on public.ai_conversations
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "ai messages owner rw" on public.ai_messages
  for all using (
    exists (select 1 from public.ai_conversations c where c.id = conversation_id and c.user_id = auth.uid())
  );

-- ---- subscriptions (owner read, admin write) ----
create policy "subscriptions owner read" on public.subscriptions
  for select using (auth.uid() = user_id or public.is_admin());
create policy "subscriptions admin write" on public.subscriptions
  for all using (public.is_admin()) with check (public.is_admin());

-- ============================================================================
-- SEED: starter subjects (matches KMTC department list from the spec)
-- ============================================================================
insert into public.subjects (name, department) values
  ('Anatomy', 'Medicine'),
  ('Physiology', 'Medicine'),
  ('Pharmacology', 'Medicine'),
  ('Biochemistry', 'Medicine'),
  ('Pathology', 'Medicine'),
  ('Microbiology', 'Medicine'),
  ('Surgery', 'Clinical Medicine'),
  ('Internal Medicine', 'Clinical Medicine'),
  ('Midwifery', 'Nursing'),
  ('Community Health', 'Public Health'),
  ('Biomedical Engineering', 'Biomedical Engineering'),
  ('Health Records', 'Health Records'),
  ('Nutrition', 'Nutrition'),
  ('Public Health', 'Public Health'),
  ('Clinical Medicine', 'Clinical Medicine')
on conflict do nothing;
